from .base import *

DEBUG = False

ALLOWED_HOSTS = config('ALLOWED_HOSTS', cast=lambda v: [s.strip() for s in v.split(',')])

# Production uses mysql as per plan
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': config('DB_NAME'),
        'USER': config('DB_USER'),
        'PASSWORD': config('DB_PASSWORD'),
        'HOST': config('DB_HOST', default='localhost'),
        'PORT': config('DB_PORT', default='3306'),
    }
}

MIDDLEWARE.insert(1, 'whitenoise.middleware.WhiteNoiseMiddleware')
STATICFILES_STORAGE = 'whitenoise.storage.CompressedManifestStaticFilesStorage'

# ==============================================================================
# PRODUCTION SECURITY SETTINGS (HTTPS Enforcement)
# ==============================================================================
# 1. Ensure CSRF cookies are only sent over HTTPS
CSRF_COOKIE_SECURE = True

# 2. Ensure Session cookies are only sent over HTTPS
SESSION_COOKIE_SECURE = True

# 3. Enable browser XSS filter
SECURE_BROWSER_XSS_FILTER = True

# 4. Prevent the site from being embedded in an iframe (Clickjacking protection)
X_FRAME_OPTIONS = 'DENY'
