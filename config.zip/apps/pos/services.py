from decimal import Decimal
from django.db import models, transaction
from django.contrib.contenttypes.models import ContentType
from django.utils import timezone
from django.conf import settings
from apps.core.models import JournalEntry, Account, TaxType
from apps.core.services import JournalService, DocumentService
from apps.inventory.models import Item, StockMovement
from apps.inventory.services import InventoryService
from apps.sales.models import SalesRepresentative, RepDailySettlement, RepSettlementInvoice
from .models import POSSession, POSOrder, POSOrderLine, POSPayment

class POSCheckoutService:
    @staticmethod
    @transaction.atomic
    def create_order(session, cart_items, payment_method, customer_id=None, is_taxable=True):
        """
        Processes checkout for a POS cart:
        1. Creates POSOrder with PAID status.
        2. Creates POSOrderLines.
        3. Records Stock Movements instantly to deduct inventory from station warehouse.
        4. Creates POSPayment.
        5. Adjusts Session Expected Cash if payment is cash.
        """
        if session.status != POSSession.Status.OPEN:
            raise ValueError("جلسة البيع هذه مغلقة ولا يمكن تسجيل فواتير جديدة عليها.")
        
        if not cart_items:
            raise ValueError("سلة المشتريات فارغة.")

        # Calculate Totals
        subtotal = Decimal('0')
        tax_amount = Decimal('0')
        grand_total = Decimal('0')
        
        # Determine tax rate based on active is_taxable status from database Lookups
        tax_rate = Decimal('0')
        if is_taxable:
            vat_tax = TaxType.objects.filter(category=TaxType.Category.VAT, is_active=True).first()
            if vat_tax:
                tax_rate = Decimal(str(vat_tax.rate)) / Decimal('100')
            else:
                tax_rate = Decimal('0.14') # Default fallback
        
        lines_data = []
        for c in cart_items:
            item_id = c.get('id')
            qty = Decimal(str(c.get('qty', 1)))
            price_inclusive = Decimal(str(c.get('price', 0)))
            unit_type = c.get('unit_type', 'base') # 'base' or 'sales'
            
            item = Item.objects.get(id=item_id)
            
            # Mathematical inverse calculation for VAT inclusive pricing
            line_total = qty * price_inclusive
            if tax_rate > 0:
                line_subtotal = line_total / (Decimal('1') + tax_rate)
                line_tax = line_total - line_subtotal
            else:
                line_subtotal = line_total
                line_tax = Decimal('0')
                
            # Business Logic Protection: Prevent selling below cost
            unit_net_price = line_subtotal / qty if qty > 0 else Decimal('0')
            avg_cost_base = InventoryService.get_item_cost(item, session.station.warehouse)
            
            # Calculate the average cost for the selected unit type
            if unit_type == 'sales' and item.sales_unit:
                current_unit_cost = avg_cost_base * item.conversion_factor
                base_qty = qty * item.conversion_factor
            else:
                current_unit_cost = avg_cost_base
                base_qty = qty
            
            if unit_net_price < current_unit_cost:
                raise ValueError(f"منع الخسارة: الصنف '{item.name}' تم تسعيره بـ {unit_net_price.quantize(Decimal('0.00'))} بينما تكلفة وقوفه عليك هي {current_unit_cost.quantize(Decimal('0.00'))}. لا يمكن إتمام البيع بأقل من التكلفة!")
            
            subtotal += line_subtotal
            tax_amount += line_tax
            grand_total += line_total
            
            lines_data.append({
                'item': item,
                'qty': qty,
                'base_qty': base_qty,
                'price': price_inclusive, # store shelf price inclusive of tax
                'tax_percent': tax_rate * Decimal('100'),
                'total': line_total
            })

        # Generate Receipt Number
        timestamp = int(timezone.now().timestamp())
        receipt_number = f"POS-{session.id}-{timestamp}"

        # Create Order
        order = POSOrder.objects.create(
            receipt_number=receipt_number,
            session=session,
            customer_id=customer_id,
            subtotal=subtotal,
            tax=tax_amount,
            grand_total=grand_total,
            status=POSOrder.Status.PAID
        )

        # Create lines and record stock movements
        for line in lines_data:
            item = line['item']
            qty = line['qty']
            base_qty = line['base_qty']
            
            # Create POS Order Line
            POSOrderLine.objects.create(
                order=order,
                item=item,
                qty=qty,
                price=line['price'],
                tax_percent=line['tax_percent'],
                total=line['total']
            )

            # Record Inventory Movement (Deduct stock instantly using BASE quantity)
            InventoryService.record_movement(
                date_val=timezone.now().date(),
                item=item,
                warehouse=session.station.warehouse,
                movement_type=StockMovement.MovementType.SALES_ISSUE,
                quantity=-base_qty,
                unit_cost=None, # auto-calculate average cost
                source=order,
                reference=f'POS Order {receipt_number}'
            )

        # Create POS Payment
        POSPayment.objects.create(
            order=order,
            method=payment_method,
            amount=grand_total,
            reference=''
        )

        # Update Session Expected Cash if Payment Method is Cash
        if payment_method == 'cash':
            session.expected_cash += grand_total
            session.save(update_fields=['expected_cash'])

        return order

class POSSessionService:
    @staticmethod
    def get_active_session(user):
        """Returns the active open session for the user, if any."""
        return POSSession.objects.filter(user=user, status=POSSession.Status.OPEN).first()

    @staticmethod
    @transaction.atomic
    def open_session(user, station, opening_cash):
        """Opens a new POSSession for the user at a specified station."""
        active = POSSessionService.get_active_session(user)
        if active:
            raise ValueError(f"لديك بالفعل جلسة مفتوحة بنقطة البيع: {active.station.name}")
            
        session = POSSession.objects.create(
            station=station,
            user=user,
            opening_cash=Decimal(str(opening_cash)),
            expected_cash=Decimal(str(opening_cash)),
            status=POSSession.Status.OPEN
        )
        return session

    @staticmethod
    @transaction.atomic
    def close_session(session, actual_cash, notes=''):
        """
        Closes a POSSession:
        1. Compares expected cash with actual cash, calculating discrepancy.
        2. Changes status to CLOSED.
        3. Creates a single consolidated Journal Entry for all shift transactions to limit database strain.
        4. If the cashier is a Sales Representative, automatically triggers a RepDailySettlement.
        """
        session = POSSession.objects.select_for_update().get(pk=session.pk)
        if session.status != POSSession.Status.OPEN:
            raise ValueError("هذه الجلسة مغلقة بالفعل.")

        actual = Decimal(str(actual_cash))
        expected = session.expected_cash
        difference = actual - expected

        session.actual_cash = actual
        session.difference = difference
        session.end_time = timezone.now()
        session.status = POSSession.Status.CLOSED
        session.save()

        # Create combined Journal Entry
        POSSessionService.create_combined_journal_entry(session, notes)

        # Trigger RepDailySettlement if user has a Sales Representative profile
        rep = SalesRepresentative.objects.filter(user=session.user).first()
        if rep:

            settlement = RepDailySettlement.objects.create(
                number=DocumentService.generate_number(RepDailySettlement, 'RS'),
                date=timezone.now().date(),
                sales_rep=rep,
                total_sales=session.expected_cash,
                cash_delivered=actual,
                difference=-difference, # negative of difference (shortage is positive in RepDailySettlement difference field)
                to_cash_box=session.station.cash_box,
                notes=f"تسوية آلية لوردية الـ POS رقم {session.id}. {notes}",
                status=RepDailySettlement.Status.DRAFT,
                created_by=session.user
            )
            session.settlement = settlement
            session.save(update_fields=['settlement'])

        return session

    @staticmethod
    def create_combined_journal_entry(session, notes=''):
        """
        Consolidates all session transactions into one combined Journal Entry:
        DR Cash Box (for Cash Payments)
        DR Bank/Visa Account (for Card Payments)
        DR Cost of Goods Sold (COGS)
        CR Sales Revenue
        CR Inventory Account
        CR VAT Tax Payable (Output VAT)
        """
        orders = POSOrder.objects.filter(session=session, status=POSOrder.Status.PAID)
        if not orders.exists():
            return None # No sales to post

        journal_lines = []

        total_cash = Decimal('0')
        total_card = Decimal('0')
        total_wallet = Decimal('0')
        total_tax = Decimal('0')

        # Accumulate payments
        payments = POSPayment.objects.filter(order__in=orders)
        for p in payments:
            if p.method == 'cash':
                total_cash += p.amount
            elif p.method == 'card':
                total_card += p.amount
            elif p.method == 'wallet':
                total_wallet += p.amount

        # Accumulate tax from order-level (authoritative source)
        for order in orders:
            total_tax += order.tax

        # Accumulate COGS by account
        cogs_by_account = {}
        inventory_by_account = {}
        revenue_by_account = {}

        # Fetch all stock movements related to these orders
        # ✅ Fix: Filter by content_type to prevent cross-model ID collision
        pos_order_ct = ContentType.objects.get_for_model(POSOrder)
        movements = StockMovement.objects.filter(
            content_type=pos_order_ct,
            object_id__in=orders.values_list('id', flat=True),
            movement_type=StockMovement.MovementType.SALES_ISSUE
        )

        for mov in movements:
            item = mov.item
            cost_val = abs(mov.total_cost) # stock issues are stored with negative cost/quantity
            
            # Group COGS
            cogs_acc = item.cogs_account
            cogs_by_account[cogs_acc.id] = cogs_by_account.get(cogs_acc.id, (cogs_acc, Decimal('0')))
            cogs_by_account[cogs_acc.id] = (cogs_acc, cogs_by_account[cogs_acc.id][1] + cost_val)

            # Group Inventory
            inv_acc = item.inventory_account
            inventory_by_account[inv_acc.id] = inventory_by_account.get(inv_acc.id, (inv_acc, Decimal('0')))
            inventory_by_account[inv_acc.id] = (inv_acc, inventory_by_account[inv_acc.id][1] + cost_val)

        # Group Revenue by Sales Account
        # ✅ Fix: Use order-level subtotal (consistent with order.tax) to avoid rounding mismatch
        for order in orders:
            # Distribute order subtotal proportionally across lines by sales account
            for line in order.lines.all():
                item = line.item
                # Calculate this line's share of the net revenue (proportional to its total)
                if order.grand_total > 0:
                    line_net = (line.total / order.grand_total) * order.subtotal
                else:
                    line_net = Decimal('0')
                
                # Fetch sales account (fallback to first Revenue account if null)
                sales_acc = item.sales_account
                if not sales_acc:
                    sales_acc = Account.objects.filter(account_type='revenue', is_leaf=True).first()
                
                if sales_acc:
                    revenue_by_account[sales_acc.id] = revenue_by_account.get(sales_acc.id, (sales_acc, Decimal('0')))
                    revenue_by_account[sales_acc.id] = (sales_acc, revenue_by_account[sales_acc.id][1] + line_net)

        # Get VAT Output Account
        vat_tax = TaxType.objects.filter(category=TaxType.Category.VAT).first()
        vat_account = vat_tax.account if vat_tax else None
        if not vat_account:
            # Fallback to standard Output VAT account
            vat_account = Account.objects.filter(code='21211').first()

        # Build Journal Entry Lines
        # Determine the correct cashbox account (prioritize Rep's cashbox over Station's default)
        rep = SalesRepresentative.objects.filter(user=session.user).first()
        cashbox_account = None
        if rep and rep.cash_box and rep.cash_box.account:
            cashbox_account = rep.cash_box.account
        elif session.station.cash_box and session.station.cash_box.account:
            cashbox_account = session.station.cash_box.account

        # 1. Debit Cash Box (Total Cash Received)
        if total_cash > 0 and cashbox_account:
            journal_lines.append({
                'account': cashbox_account,
                'debit': total_cash,
                'credit': Decimal('0'),
                'description': f"إجمالي المقبوضات النقدية للوردية رقم {session.id}"
            })

        # 2. Debit Bank Account (Total Card Received)
        # ✅ Fix: Use .account to get the GL Account, not the BankAccount model itself
        if total_card > 0 and session.station.bank_account and session.station.bank_account.account:
            journal_lines.append({
                'account': session.station.bank_account.account,
                'debit': total_card,
                'credit': Decimal('0'),
                'description': f"إجمالي مقبوضات الشبكة للوردية رقم {session.id}"
            })

        # 2.5. Debit Mobile Wallet (Total Wallet Received)
        if total_wallet > 0:
            wallet_account = None
            if getattr(session.station, 'mobile_wallet', None) and session.station.mobile_wallet.account:
                wallet_account = session.station.mobile_wallet.account
            elif session.station.cash_box and session.station.cash_box.account:
                wallet_account = session.station.cash_box.account
                
            if wallet_account:
                journal_lines.append({
                    'account': wallet_account,
                    'debit': total_wallet,
                    'credit': Decimal('0'),
                    'description': f"إجمالي مقبوضات المحفظة الإلكترونية للوردية رقم {session.id}"
                })

        # 3. Debit COGS Accounts
        for acc_id, (acc, amount) in cogs_by_account.items():
            if amount > 0:
                journal_lines.append({
                    'account': acc,
                    'debit': amount,
                    'credit': Decimal('0'),
                    'description': f"تكلفة المبيعات المجمعة للوردية رقم {session.id}"
                })

        # 4. Credit Sales Revenue Accounts
        for acc_id, (acc, amount) in revenue_by_account.items():
            if amount > 0:
                journal_lines.append({
                    'account': acc,
                    'debit': Decimal('0'),
                    'credit': amount,
                    'description': f"إيراد المبيعات المجمع للوردية رقم {session.id}"
                })

        # 5. Credit Inventory Accounts
        for acc_id, (acc, amount) in inventory_by_account.items():
            if amount > 0:
                journal_lines.append({
                    'account': acc,
                    'debit': Decimal('0'),
                    'credit': amount,
                    'description': f"صرف مخزون مجمع للوردية رقم {session.id}"
                })

        # 6. Credit Output VAT
        if total_tax > 0 and vat_account:
            journal_lines.append({
                'account': vat_account,
                'debit': Decimal('0'),
                'credit': total_tax,
                'description': f"ضريبة القيمة المضافة المخرجة لوردية POS رقم {session.id}"
            })

        # Create Journal Entry
        from apps.core.models import FiscalYear
        fy = FiscalYear.objects.filter(is_closed=False).first()
        if not fy:
            today = timezone.now().date()
            fy, _ = FiscalYear.objects.get_or_create(
                name=f"FY {today.year}",
                defaults={
                    'start_date': today.replace(month=1, day=1),
                    'end_date': today.replace(month=12, day=31),
                    'is_closed': False
                }
            )

        # Verify entry balances perfectly before submitting
        debit_sum = sum(x['debit'] for x in journal_lines)
        credit_sum = sum(x['credit'] for x in journal_lines)
        
        # Prevent any fractional rounding issues from causing transaction reject
        diff = debit_sum - credit_sum
        if abs(diff) > 0 and abs(diff) < Decimal('0.05'):
            # Round off the diff to the biggest cash or revenue line
            for line in journal_lines:
                if line['debit'] > 0:
                    line['debit'] -= diff
                    break

        if journal_lines:
            entry = JournalService.create_entry(
                date_val=timezone.now().date(),
                entry_type=JournalEntry.EntryType.SALE,
                description=f"قيد المبيعات اليومي المجمع لوردية نقطة البيع رقم {session.id}",
                lines=journal_lines,
                source_document=session,
                created_by=session.user
            )
            # Mark all orders in the session as POSTED now that financial entry is done
            orders.update(status=POSOrder.Status.POSTED)
            return entry

        return None
