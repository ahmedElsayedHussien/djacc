from django.db import models
from django.conf import settings
from apps.core.models import ConcurrencyModel

class POSStation(ConcurrencyModel):
    """نقطة البيع (الكاشير كجهاز أو محطة عمل)"""
    code = models.CharField(max_length=20, unique=True, verbose_name="كود النقطة")
    name = models.CharField(max_length=100, verbose_name="اسم نقطة البيع")
    warehouse = models.ForeignKey('inventory.Warehouse', on_delete=models.PROTECT, verbose_name="المخزن المرتبط (لسحب البضاعة)")
    cash_box = models.ForeignKey('treasury.CashBox', on_delete=models.PROTECT, verbose_name="درج النقدية (الخزينة الافتراضية)")
    bank_account = models.ForeignKey('treasury.BankAccount', null=True, blank=True, on_delete=models.SET_NULL, verbose_name="حساب البنك (لمدفوعات الفيزا)")
    mobile_wallet = models.ForeignKey('treasury.MobileWallet', null=True, blank=True, on_delete=models.SET_NULL, verbose_name="المحفظة الإلكترونية المرتبطة")
    is_active = models.BooleanField(default=True, verbose_name="نشط")

    class Meta:
        verbose_name = "نقطة بيع"
        verbose_name_plural = "نقاط البيع"

    def __str__(self):
        return f"{self.name} - {self.warehouse.name}"

class POSSession(ConcurrencyModel):
    """وردية الكاشير (جلسة العمل من الفتح للإغلاق)"""
    class Status(models.TextChoices):
        OPEN = 'open', 'مفتوحة (قيد العمل)'
        CLOSED = 'closed', 'مغلقة'
        POSTED = 'posted', 'مرحّلة (تمت التسوية)'

    station = models.ForeignKey(POSStation, on_delete=models.PROTECT, related_name='sessions', verbose_name="نقطة البيع")
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, verbose_name="الكاشير (المستخدم)")
    
    start_time = models.DateTimeField(auto_now_add=True, verbose_name="وقت فتح الوردية")
    end_time = models.DateTimeField(null=True, blank=True, verbose_name="وقت إغلاق الوردية")
    
    opening_cash = models.DecimalField(max_digits=18, decimal_places=2, default=0, verbose_name="عُهدة الفتح (الكاش المبدئي)")
    expected_cash = models.DecimalField(max_digits=18, decimal_places=2, default=0, verbose_name="النقدية المتوقعة بنهاية الوردية")
    actual_cash = models.DecimalField(max_digits=18, decimal_places=2, default=0, verbose_name="النقدية الفعلية (الجرد الفعلي)")
    difference = models.DecimalField(max_digits=18, decimal_places=2, default=0, verbose_name="العجز / الزيادة")
    
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.OPEN, verbose_name="حالة الوردية")
    
    # 🔗 جسر العبور للـ ERP الخلفي
    settlement = models.OneToOneField(
        'sales.RepDailySettlement', 
        null=True, blank=True, 
        on_delete=models.SET_NULL, 
        verbose_name="التسوية اليومية المرتبطة بالـ ERP"
    )

    class Meta:
        verbose_name = "وردية نقطة بيع"
        verbose_name_plural = "ورديات نقاط البيع"

    def __str__(self):
        return f"وردية {self.user.username} - {self.station.name} ({self.start_time.strftime('%Y-%m-%d')})"

class POSOrder(ConcurrencyModel):
    """إيصال البيع (الفاتورة السريعة للعميل الطيار)"""
    class Status(models.TextChoices):
        DRAFT = 'draft', 'مسودة (قيد الإدخال)'
        PAID = 'paid', 'مدفوعة (جاهزة للتسليم)'
        POSTED = 'posted', 'مرحّلة للـ ERP (كفاتورة مبيعات)'
        CANCELLED = 'cancelled', 'ملغاة'

    receipt_number = models.CharField(max_length=50, unique=True, verbose_name="رقم الإيصال")
    session = models.ForeignKey(POSSession, on_delete=models.PROTECT, related_name='orders', verbose_name="الوردية")
    date = models.DateTimeField(auto_now_add=True, verbose_name="وقت الطلب")
    
    customer = models.ForeignKey('sales.Customer', null=True, blank=True, on_delete=models.SET_NULL, verbose_name="العميل (يُترك فارغاً للعميل النقدي)")
    
    # الأرقام الإجمالية السريعة
    subtotal = models.DecimalField(max_digits=18, decimal_places=2, default=0, verbose_name="الإجمالي قبل الضريبة والخصم")
    discount = models.DecimalField(max_digits=18, decimal_places=2, default=0, verbose_name="الخصم")
    tax = models.DecimalField(max_digits=18, decimal_places=2, default=0, verbose_name="الضريبة")
    grand_total = models.DecimalField(max_digits=18, decimal_places=2, default=0, verbose_name="الصافي المطلوب")
    
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.DRAFT, verbose_name="الحالة")
    
    # 🔗 جسر العبور للـ ERP الخلفي
    sales_invoice = models.OneToOneField(
        'sales.SalesInvoice', 
        null=True, blank=True, 
        on_delete=models.SET_NULL, 
        verbose_name="فاتورة المبيعات الضريبية المرتبطة"
    )

    class Meta:
        verbose_name = "طلب نقطة بيع"
        verbose_name_plural = "طلبات نقاط البيع"

    def __str__(self):
        return self.receipt_number

class POSOrderLine(models.Model):
    """سطر المنتجات داخل إيصال الـ POS"""
    order = models.ForeignKey(POSOrder, on_delete=models.CASCADE, related_name='lines')
    item = models.ForeignKey('inventory.Item', on_delete=models.PROTECT, verbose_name="الصنف")
    qty = models.DecimalField(max_digits=14, decimal_places=4, verbose_name="الكمية")
    price = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="سعر الوحدة")
    discount = models.DecimalField(max_digits=18, decimal_places=2, default=0, verbose_name="خصم السطر")
    tax_percent = models.DecimalField(max_digits=5, decimal_places=2, default=0, verbose_name="نسبة الضريبة")
    total = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="إجمالي السطر")

    class Meta:
        verbose_name = "سطر طلب نقطة بيع"
        verbose_name_plural = "أسطر طلبات نقاط البيع"

    def __str__(self):
        return f"{self.item.name} x {self.qty}"

class POSPayment(models.Model):
    """مدفوعات الإيصال (يتيح للعميل الدفع كاش وفيزا لنفس الفاتورة)"""
    class PaymentMethod(models.TextChoices):
        CASH = 'cash', 'كاش (نقدية)'
        CARD = 'card', 'بطاقة بنكية (فيزا/ماستركارد)'
        WALLET = 'wallet', 'محفظة إلكترونية / فوري'

    order = models.ForeignKey(POSOrder, on_delete=models.CASCADE, related_name='payments')
    method = models.CharField(max_length=20, choices=PaymentMethod.choices, default=PaymentMethod.CASH, verbose_name="طريقة الدفع")
    amount = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="المبلغ المدفوع")
    reference = models.CharField(max_length=100, blank=True, verbose_name="رقم العملية (للفيزا/المحفظة)")
    
    date = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "مدفوعات نقطة بيع"
        verbose_name_plural = "مدفوعات نقاط البيع"

    def __str__(self):
        return f"{self.get_method_display()} - {self.amount}"
