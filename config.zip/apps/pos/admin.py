from django.contrib import admin
from .models import POSStation, POSSession, POSOrder, POSOrderLine, POSPayment

@admin.register(POSStation)
class POSStationAdmin(admin.ModelAdmin):
    list_display = ['code', 'name', 'warehouse', 'cash_box', 'is_active']
    search_fields = ['code', 'name']
    list_filter = ['is_active', 'warehouse']

@admin.register(POSSession)
class POSSessionAdmin(admin.ModelAdmin):
    list_display = ['user', 'station', 'status', 'start_time', 'end_time', 'opening_cash']
    list_filter = ['status', 'station', 'user']
    search_fields = ['user__username', 'station__name']

class POSOrderLineInline(admin.TabularInline):
    model = POSOrderLine
    extra = 1

class POSPaymentInline(admin.TabularInline):
    model = POSPayment
    extra = 1

@admin.register(POSOrder)
class POSOrderAdmin(admin.ModelAdmin):
    list_display = ['receipt_number', 'session', 'date', 'customer', 'grand_total', 'status']
    list_filter = ['status', 'date']
    search_fields = ['receipt_number', 'customer__name']
    inlines = [POSOrderLineInline, POSPaymentInline]
