from django import forms
from .models import POSStation
from apps.inventory.models import Warehouse
from apps.treasury.models import CashBox, BankAccount, MobileWallet

class POSStationForm(forms.ModelForm):
    class Meta:
        model = POSStation
        fields = ['code', 'name', 'warehouse', 'cash_box', 'bank_account', 'mobile_wallet', 'is_active']
        widgets = {
            'code': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'مثال: POS-01'}),
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'مثال: كاشير الصيدلية'}),
            'warehouse': forms.Select(attrs={'class': 'form-select'}),
            'cash_box': forms.Select(attrs={'class': 'form-select'}),
            'bank_account': forms.Select(attrs={'class': 'form-select'}),
            'mobile_wallet': forms.Select(attrs={'class': 'form-select'}),
            'is_active': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        }
