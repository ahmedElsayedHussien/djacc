import json
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from apps.inventory.models import Item, ItemCategory
from .models import POSStation, POSSession
from .services import POSSessionService, POSCheckoutService
from .forms import POSStationForm

@login_required
def pos_dashboard(request):
    """
    Main entry point for the POS Interface.
    Checks if user has an active session. If not, passes POSStations to let them open a session.
    Preloads all active items and categories as JSON for lightning-fast client-side rendering.
    """
    # Check for active open session
    active_session = POSSessionService.get_active_session(request.user)
    
    stations = []
    if not active_session:
        stations = POSStation.objects.filter(is_active=True)
        
    categories = ItemCategory.objects.all()
    items = Item.objects.filter(is_active=True).select_related('category')
    
    # Pre-serialize items for high-speed JS client operations
    items_list = []
    for item in items:
        items_list.append({
            'id': item.id,
            'name': item.name,
            'code': item.code,
            'barcode': item.barcode or '',
            'price': float(item.standard_price) if item.standard_price else 0.0,
            'category_id': item.category_id if item.category else None,
            'category_name': item.category.name if item.category else 'عام',
            'unit_name': item.base_unit.name if item.base_unit else 'حبة',
            'base_unit_id': item.base_unit.id if item.base_unit else None,
            'base_unit_name': item.base_unit.name if item.base_unit else 'حبة',
            'sales_unit_id': item.sales_unit.id if item.sales_unit else None,
            'sales_unit_name': item.sales_unit.name if item.sales_unit else '',
            'conversion_factor': float(item.conversion_factor) if item.conversion_factor else 1.0,
        })
        
    context = {
        'active_session': active_session,
        'stations': stations,
        'categories': categories,
        'items_json': items_list,
    }
    
    return render(request, 'pos/dashboard.html', context)

@login_required
@require_POST
def open_session(request):
    """Creates a new POS session for the cashier."""
    station_id = request.POST.get('station')
    opening_cash = request.POST.get('opening_cash', 0)
    
    try:
        station = POSStation.objects.get(id=station_id, is_active=True)
        POSSessionService.open_session(request.user, station, opening_cash)
        return redirect('pos:dashboard')
    except Exception as e:
        # Re-render dashboard with errors
        return redirect('pos:dashboard')

@login_required
@require_POST
def checkout(request):
    """Processes the checkout of the cart."""
    active_session = POSSessionService.get_active_session(request.user)
    if not active_session:
        return JsonResponse({'success': False, 'message': 'لا توجد جلسة عمل مفتوحة حالياً.'}, status=400)
        
    try:
        data = json.loads(request.body)
        cart = data.get('cart', [])
        payment_method = data.get('payment_method', 'cash')
        customer_id = data.get('customer_id') # optional
        is_taxable = data.get('is_taxable', True) # optional
        
        order = POSCheckoutService.create_order(
            session=active_session,
            cart_items=cart,
            payment_method=payment_method,
            customer_id=customer_id,
            is_taxable=is_taxable
        )
        
        return JsonResponse({
            'success': True,
            'message': 'تم حفظ ودفع الفاتورة بنجاح وصرف المخزون.',
            'receipt_number': order.receipt_number,
            'grand_total': float(order.grand_total)
        })
    except Exception as e:
        return JsonResponse({'success': False, 'message': str(e)}, status=400)

@login_required
@require_POST
def close_session(request):
    """Closes the current cashier session and submits daily sales settlements."""
    active_session = POSSessionService.get_active_session(request.user)
    if not active_session:
        return JsonResponse({'success': False, 'message': 'لا توجد جلسة عمل مفتوحة لإغلاقها.'}, status=400)
        
    try:
        data = json.loads(request.body)
        actual_cash = data.get('actual_cash', 0)
        notes = data.get('notes', '')
        
        POSSessionService.close_session(active_session, actual_cash, notes)
        
        return JsonResponse({
            'success': True,
            'message': 'تم إغلاق الوردية بنجاح وترحيل القيود المحاسبية للمبيعات وتوليد تسوية الخزنة.'
        })
    except Exception as e:
        return JsonResponse({'success': False, 'message': str(e)}, status=400)

@login_required
def station_list(request):
    stations = POSStation.objects.all().select_related('warehouse', 'cash_box', 'bank_account')
    return render(request, 'pos/station_list.html', {'stations': stations})

@login_required
def station_create(request):
    if request.method == 'POST':
        form = POSStationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('pos:station-list')
    else:
        form = POSStationForm()
    return render(request, 'pos/station_form.html', {'form': form, 'title': 'إضافة نقطة بيع جديدة'})

@login_required
def station_update(request, pk):
    station = get_object_or_404(POSStation, pk=pk)
    if request.method == 'POST':
        form = POSStationForm(request.POST, instance=station)
        if form.is_valid():
            form.save()
            return redirect('pos:station-list')
    else:
        form = POSStationForm(instance=station)
    return render(request, 'pos/station_form.html', {'form': form, 'title': f'تعديل نقطة البيع: {station.name}'})

@login_required
def station_delete(request, pk):
    station = get_object_or_404(POSStation, pk=pk)
    if request.method == 'POST':
        station.delete()
        return redirect('pos:station-list')
    return render(request, 'pos/station_confirm_delete.html', {'station': station})

@login_required
def session_list(request):
    """Lists past and active POS sessions with summary statistics."""
    from django.db.models import Sum
    from decimal import Decimal
    from .models import POSPayment
    
    sessions = POSSession.objects.all().select_related('station', 'user').order_by('-start_time')
    
    sessions_data = []
    for s in sessions:
        orders = s.orders.all()
        total_sales = orders.aggregate(total=Sum('grand_total'))['total'] or Decimal('0')
        payments = POSPayment.objects.filter(order__session=s)
        total_cash = payments.filter(method='cash').aggregate(total=Sum('amount'))['total'] or Decimal('0')
        total_card = payments.filter(method='card').aggregate(total=Sum('amount'))['total'] or Decimal('0')
        total_wallet = payments.filter(method='wallet').aggregate(total=Sum('amount'))['total'] or Decimal('0')
        
        sessions_data.append({
            'session': s,
            'total_sales': total_sales,
            'total_cash': total_cash,
            'total_card': total_card,
            'total_wallet': total_wallet,
        })
        
    return render(request, 'pos/session_list.html', {'sessions_data': sessions_data})
