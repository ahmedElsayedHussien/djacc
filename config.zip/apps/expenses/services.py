from django.db import transaction
from apps.core.models import JournalEntry
from apps.core.services import JournalService
from .models import Expense, Custody, CustodySettlement

class ExpenseService:
    @staticmethod
    @transaction.atomic
    def post_expense(expense: Expense, posted_by) -> JournalEntry:
        """
        Expense Journal Entry:
        DR  Expense Account (from category)    → expense.amount
        CR  Cash/Bank/Custody Account           → expense.amount
        """
        if expense.status == Expense.Status.POSTED:
            raise ValueError("هذا المصروف مرحل بالفعل")
        if expense.status != Expense.Status.APPROVED:
            raise ValueError("يجب اعتماد المصروف قبل الترحيل")
        lines = []
        
        lines.append({
            'account': expense.category.account,
            'debit': expense.amount,
            'credit': 0,
            'description': f'مصروف: {expense.description}',
            'cost_center': expense.cost_center,
        })
        
        # Credit Payment Source
        if expense.payment_method == 'cash':
            account = expense.cash_box.account
        elif expense.payment_method == 'bank':
            account = expense.bank_account.account
        else: # custody
            account = expense.custody.account
            
        lines.append({
            'account': account,
            'debit': 0,
            'credit': expense.amount,
            'description': f'سداد مصروف {expense.number}'
        })
        
        entry = JournalService.create_entry(
            date_val=expense.date,
            entry_type=JournalEntry.EntryType.EXPENSE,
            description=f'قيد مصروف رقم {expense.number}',
            lines=lines,
            source_document=expense,
            created_by=posted_by,
        )
        
        expense.journal_entry = entry
        expense.status = Expense.Status.POSTED
        expense.save()
        return entry

class CustodyService:
    @staticmethod
    @transaction.atomic
    def issue_custody(custody: Custody, created_by) -> JournalEntry:
        """
        DR  Employee Advance Account          → custody.amount
        CR  Cash Box                          → custody.amount
        """
        lines = [
            {'account': custody.account, 'debit': custody.amount, 'credit': 0, 'description': f'إصدار عهدة {custody.number}'},
            {'account': custody.cash_box.account, 'debit': 0, 'credit': custody.amount, 'description': f'صرف عهدة {custody.number}'},
        ]
        
        entry = JournalService.create_entry(
            date_val=custody.date,
            entry_type=JournalEntry.EntryType.CUSTODY,
            description=f'قيد عهدة رقم {custody.number}',
            lines=lines,
            source_document=custody,
            created_by=created_by,
        )
        custody.journal_entry = entry
        custody.save()
        return entry

    @staticmethod
    @transaction.atomic
    def settle_custody(settlement: CustodySettlement, created_by) -> JournalEntry:
        """
        Journal Entry for Custody Settlement:
        DR  Expense Accounts (for each expense)   → expense.amount
        DR  Cash Box (if refund)                  → settlement.returned_amount
        """
        if settlement.is_posted:
            raise ValueError("هذه التسوية مرحلة بالفعل")
            
        lines = []
        entry = None
        
        # 1. Add Expenses (DEBIT)
        expenses = settlement.custody.expense_set.filter(status='posted')
        total_expenses = 0
        for exp in expenses:
            lines.append({
                'account': exp.category.account,
                'debit': exp.amount,
                'credit': 0,
                'description': f'مصروف من عهدة {settlement.custody.number}: {exp.description}',
                'cost_center': exp.cost_center,
            })
            total_expenses += exp.amount
            
        # 2. Add Refund (DEBIT)
        if settlement.returned_amount > 0:
            lines.append({
                'account': settlement.cash_box.account,
                'debit': settlement.returned_amount,
                'credit': 0,
                'description': f'رد متبقي عهدة {settlement.custody.number}'
            })
            
        total_settled = total_expenses + settlement.returned_amount
        
        # 3. Close Custody Account (CREDIT)
        if total_settled > 0:
            lines.append({
                'account': settlement.custody.account,
                'debit': 0,
                'credit': total_settled,
                'description': f'تسوية إجمالي عهدة {settlement.custody.number}'
            })

            entry = JournalService.create_entry(
                date_val=settlement.date,
                entry_type=JournalEntry.EntryType.CUSTODY,
                description=f'تسوية عهدة رقم {settlement.custody.number}',
                lines=lines,
                source_document=settlement,
                created_by=created_by,
            )
            settlement.journal_entry = entry
        settlement.expenses_amount = total_expenses
        # No need to save here, we'll save below after updating everything
        
        # 4. Update Custody Status
        custody = settlement.custody
        # Total settled is the sum of all settlements' returned_amount + total of all posted expenses
        total_returned = custody.custodysettlement_set.aggregate(t=Sum('returned_amount'))['t'] or 0
        if settlement.pk is None: # If not saved yet, include current returned_amount
             total_returned += settlement.returned_amount
             
        total_expenses = custody.expense_set.filter(status='posted').aggregate(t=Sum('amount'))['t'] or 0
        
        custody.settled_amount = total_returned + total_expenses
        
        if custody.settled_amount >= custody.amount:
            custody.status = Custody.Status.SETTLED
        else:
            custody.status = Custody.Status.PARTIALLY_SETTLED
            
        settlement.is_posted = True
        settlement.save()
        custody.save()
        return entry
