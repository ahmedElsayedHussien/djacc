from django.views.generic import ListView, CreateView, UpdateView, DetailView
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.urls import reverse_lazy
from django.contrib import messages
from django.shortcuts import redirect
from django.views import View
from .models import Expense, ExpenseCategory, Custody
from .forms import ExpenseForm, ExpenseCategoryForm, CustodyForm
from .services import ExpenseService # Assuming it exists based on dir listing

class ExpenseListView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    model = Expense
    template_name = 'expenses/list.html'
    context_object_name = 'expenses'
    permission_required = 'expenses.view_expense'
    paginate_by = 25

class ExpenseCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    model = Expense
    form_class = ExpenseForm
    template_name = 'expenses/form.html'
    success_url = reverse_lazy('expenses:expense-list')
    permission_required = 'expenses.add_expense'

    def form_valid(self, form):
        from apps.core.services import DocumentService
        form.instance.number = DocumentService.generate_number(Expense, 'EXP')
        form.instance.created_by = self.request.user
        messages.success(self.request, f'تم تسجيل المصروف {form.instance.number} بنجاح')
        return super().form_valid(form)

class ExpensePostView(LoginRequiredMixin, PermissionRequiredMixin, View):
    permission_required = 'expenses.change_expense'
    
    def post(self, request, pk):
        from .services import ExpenseService
        expense = Expense.objects.get(pk=pk)
        if expense.status == Expense.Status.POSTED:
            messages.warning(request, "هذا المصروف تم ترحيله بالفعل")
            return redirect('expenses:expense-detail', pk=pk)
            
        try:
            ExpenseService.post_expense(expense, request.user)
            messages.success(request, f'تم اعتماد وترحيل المصروف {expense.number}')
        except Exception as e:
            messages.error(request, f'خطأ في الاعتماد: {e}')
        return redirect('expenses:expense-detail', pk=pk)

class ExpenseCategoryListView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    model = ExpenseCategory
    template_name = 'expenses/categories/list.html'
    permission_required = 'expenses.view_expensecategory'

class ExpenseCategoryCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    model = ExpenseCategory
    form_class = ExpenseCategoryForm
    template_name = 'expenses/categories/form.html'
    success_url = reverse_lazy('expenses:category-list')
    permission_required = 'expenses.add_expensecategory'

class CustodyListView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    model = Custody
    template_name = 'expenses/custody/list.html'
    permission_required = 'expenses.view_custody'

class CustodyCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    model = Custody
    form_class = CustodyForm
    template_name = 'expenses/custody/form.html'
    success_url = reverse_lazy('expenses:custody-list')
    permission_required = 'expenses.add_custody'

    def form_valid(self, form):
        from apps.core.services import DocumentService
        from .services import CustodyService
        from django.db import transaction
        
        with transaction.atomic():
            form.instance.number = DocumentService.generate_number(Custody, 'CUS')
            form.instance.created_by = self.request.user
            response = super().form_valid(form)
            CustodyService.issue_custody(self.object, self.request.user)
            messages.success(self.request, f'تم صرف العهدة رقم {self.object.number} وإنشاء القيد المحاسبي بنجاح.')
            return response

class ExpenseDetailView(LoginRequiredMixin, PermissionRequiredMixin, DetailView):
    model = Expense
    template_name = 'expenses/detail.html'
    context_object_name = 'expense'
    permission_required = 'expenses.view_expense'

class CustodyDetailView(LoginRequiredMixin, PermissionRequiredMixin, DetailView):
    model = Custody
    template_name = 'expenses/custody/detail.html'
    context_object_name = 'custody'
    permission_required = 'expenses.view_custody'

from .models import CustodySettlement
from .forms import CustodySettlementForm

class CustodySettlementCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    model = CustodySettlement
    form_class = CustodySettlementForm
    template_name = 'expenses/custody/settlement_form.html'
    permission_required = 'expenses.add_custodysettlement'
    
    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        from django.shortcuts import get_object_or_404
        custody = get_object_or_404(Custody, pk=self.kwargs['custody_pk'])
        ctx['custody'] = custody
        
        # Calculate pending expenses
        from django.db.models import Sum
        expenses = custody.expense_set.filter(status='posted')
        total_expenses = expenses.aggregate(t=Sum('amount'))['t'] or 0
        ctx['pending_expenses'] = expenses
        ctx['total_expenses'] = total_expenses
        ctx['remaining_balance'] = custody.amount - custody.settled_amount - total_expenses
        return ctx
        
    def form_valid(self, form):
        from django.shortcuts import get_object_or_404
        from .services import CustodyService
        from django.db import transaction
        
        with transaction.atomic():
            custody = get_object_or_404(Custody, pk=self.kwargs['custody_pk'])
            form.instance.custody = custody
            
            self.object = form.save()
            CustodyService.settle_custody(self.object, self.request.user)
            
            messages.success(self.request, 'تمت تسوية العهدة بنجاح')
            return redirect('expenses:custody-detail', pk=custody.pk)
