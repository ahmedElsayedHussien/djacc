from rest_framework import viewsets, permissions
from apps.core.models import Account, JournalEntry
from apps.sales.models import Customer, SalesInvoice
from apps.purchases.models import Supplier, PurchaseInvoice
from .serializers import (
    AccountSerializer, JournalEntrySerializer, 
    CustomerSerializer, SalesInvoiceSerializer,
    SupplierSerializer, PurchaseInvoiceSerializer
)

class AccountViewSet(viewsets.ReadOnlyModelViewSet):
    """ReadOnly to protect financial structure integrity"""
    queryset = Account.objects.all()
    serializer_class = AccountSerializer
    permission_classes = [permissions.IsAuthenticated]

class JournalEntryViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = JournalEntry.objects.all()
    serializer_class = JournalEntrySerializer
    permission_classes = [permissions.IsAuthenticated]

class CustomerViewSet(viewsets.ModelViewSet):
    queryset = Customer.objects.all()
    serializer_class = CustomerSerializer
    permission_classes = [permissions.IsAuthenticated]

class SalesInvoiceViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = SalesInvoice.objects.all()
    serializer_class = SalesInvoiceSerializer
    permission_classes = [permissions.IsAuthenticated]

class SupplierViewSet(viewsets.ModelViewSet):
    queryset = Supplier.objects.all()
    serializer_class = SupplierSerializer
    permission_classes = [permissions.IsAuthenticated]

class PurchaseInvoiceViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = PurchaseInvoice.objects.all()
    serializer_class = PurchaseInvoiceSerializer
    permission_classes = [permissions.IsAuthenticated]
