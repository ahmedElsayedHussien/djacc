from datetime import date
from decimal import Decimal
from django.db import transaction
from django.utils import timezone
from apps.core.services import JournalService, AuditService
from apps.core.models import JournalEntry
from .models import Asset, DepreciationLog

class AssetService:

    @staticmethod
    @transaction.atomic
    def register_asset(asset: Asset, offset_account, created_by, entry_date=None) -> None:
        """
        يُنشئ القيود المحاسبية اللازمة عند تسجيل أصل ثابت:

        1. قيد شراء الأصل / الرصيد الافتتاحي:
           DR  حساب الأصل (12xx)                       ← purchase_value
           CR  حساب مقابل (نقدية / مورد / ح/35)       ← purchase_value

        2. قيد مجمع الإهلاك الافتتاحي (إن وجد):
           DR  حساب مقابل (ح/35)                       ← initial_accumulated_depreciation
           CR  مجمع الإهلاك (12xx)                     ← initial_accumulated_depreciation
        """
        from apps.core.models import JournalEntry
        from apps.core.services import JournalService

        if entry_date is None:
            entry_date = asset.purchase_date

        asset_account = asset.category.asset_account
        acc_dep_account = asset.category.accumulated_depreciation_account

        # ── 1. قيد تسجيل الأصل ─────────────────────────────────────────
        lines = [
            {
                'account': asset_account,
                'debit': asset.purchase_value,
                'credit': 0,
                'description': f'تسجيل أصل: {asset.name} ({asset.code})'
            },
            {
                'account': offset_account,
                'debit': 0,
                'credit': asset.purchase_value,
                'description': f'مقابل تسجيل أصل: {asset.name} ({asset.code})'
            },
        ]

        JournalService.create_entry(
            date_val=entry_date,
            entry_type=JournalEntry.EntryType.MANUAL,
            description=f'قيد تسجيل أصل ثابت: {asset.name}',
            lines=lines,
            source_document=asset,
            created_by=created_by,
        )

        # ── 2. قيد مجمع الإهلاك الافتتاحي ─────────────────────────────
        if asset.initial_accumulated_depreciation > 0:
            JournalService.create_entry(
                date_val=entry_date,
                entry_type=JournalEntry.EntryType.MANUAL,
                description=f'مجمع إهلاك افتتاحي: {asset.name}',
                lines=[
                    {
                        'account': offset_account,
                        'debit': asset.initial_accumulated_depreciation,
                        'credit': 0,
                        'description': f'ح/مقابل مجمع إهلاك افتتاحي - {asset.name}'
                    },
                    {
                        'account': acc_dep_account,
                        'debit': 0,
                        'credit': asset.initial_accumulated_depreciation,
                        'description': f'مجمع إهلاك افتتاحي - {asset.name}'
                    },
                ],
                source_document=asset,
                created_by=created_by,
            )


    @staticmethod
    @transaction.atomic
    def run_depreciation(target_date: date, created_by) -> int:
        """
        يجرى حساب وإثبات إهلاك كافة الأصول النشطة حتى التاريخ المحدد (عادة نهاية الشهر).
        """
        active_assets = Asset.objects.filter(status=Asset.Status.ACTIVE)
        processed_count = 0
        
        for asset in active_assets:
            # Check if already depreciated for this month
            month_start = target_date.replace(day=1)
            if DepreciationLog.objects.filter(asset=asset, date__gte=month_start, date__lte=target_date).exists():
                continue
                
            # Calculate monthly amount
            annual_rate = asset.depreciation_rate / Decimal('100')
            monthly_amount = (asset.purchase_value - asset.salvage_value) * annual_rate / Decimal('12')
            monthly_amount = monthly_amount.quantize(Decimal('0.01'))
            
            # Ensure we don't exceed book value
            remaining_to_depreciate = asset.book_value - asset.salvage_value
            if monthly_amount > remaining_to_depreciate:
                monthly_amount = remaining_to_depreciate
            
            if monthly_amount <= 0:
                asset.status = Asset.Status.FULLY_DEPRECIATED
                asset.save()
                continue

            # 1. Create Journal Entry
            lines = [
                {
                    'account': asset.category.depreciation_expense_account,
                    'debit': monthly_amount,
                    'credit': 0,
                    'description': f'إهلاك شهر {target_date.month}/{target_date.year} - {asset.name}'
                },
                {
                    'account': asset.category.accumulated_depreciation_account,
                    'debit': 0,
                    'credit': monthly_amount,
                    'description': f'مجمع إهلاك - {asset.name}'
                }
            ]
            
            entry = JournalService.create_entry(
                date_val=target_date,
                entry_type=JournalEntry.EntryType.MANUAL,
                description=f'قيد إهلاك أصول - {target_date.strftime("%B %Y")}',
                lines=lines,
                created_by=created_by,
                source_document=asset
            )
            
            # 2. Record Log
            DepreciationLog.objects.create(
                asset=asset,
                date=target_date,
                amount=monthly_amount,
                journal_entry=entry
            )
            
            # 3. Audit Log
            AuditService.log(created_by, 'Depreciate', asset, f'إثبات إهلاك شهري بقيمة {monthly_amount}')
            
            processed_count += 1
            
        return processed_count

    @staticmethod
    @transaction.atomic
    def create_category_with_accounts(name, depreciation_rate, created_by):
        """
        تنشئ تصنيف جديد مع فحص وجود الحسابات أولاً قبل إنشائها (لتجنب التكرار).
        """
        from apps.core.models import Account, AccountType
        
        # 1. تحديد الحسابات الأب
        fixed_assets_parent = Account.objects.get(code='12')
        acc_dep_parent = Account.objects.get(code='129')
        try:
            dep_exp_parent = Account.objects.get(code='526')
        except Account.DoesNotExist:
            dep_exp_parent = Account.objects.filter(name__icontains='إهلاك', code__startswith='5').first()
            if not dep_exp_parent:
                dep_exp_parent = Account.objects.get(code='5')

        def get_or_create_account(parent, acc_name, acc_type, initial_type='debit'):
            # البحث عن حساب مطابق بالاسم تحت نفس الأب
            existing = Account.objects.filter(parent=parent, name__icontains=acc_name).first()
            if existing:
                return existing
            
            # إذا لم يوجد، ننشئ كود جديد
            last = Account.objects.filter(parent=parent).order_by('-code').first()
            if last:
                try:
                    new_code = str(int(last.code) + 1)
                except ValueError:
                    new_code = parent.code + "01"
            else:
                new_code = parent.code + "01"
                
            return Account.objects.create(
                code=new_code,
                name=acc_name,
                account_type=acc_type,
                parent=parent,
                is_leaf=True,
                initial_balance_type=initial_type
            )

        # 2. الحصول على الحسابات (أو إنشاؤها)
        asset_acc = get_or_create_account(fixed_assets_parent, f"أصول - {name}", AccountType.ASSET)
        acc_dep_acc = get_or_create_account(acc_dep_parent, f"مجمع إهلاك - {name}", AccountType.ASSET, 'credit')
        dep_exp_acc = get_or_create_account(dep_exp_parent, f"مصروف إهلاك - {name}", AccountType.EXPENSE)
        
        # 3. إنشاء التصنيف
        from .models import AssetCategory
        category = AssetCategory.objects.create(
            name=name,
            asset_account=asset_acc,
            accumulated_depreciation_account=acc_dep_acc,
            depreciation_expense_account=dep_exp_acc,
            default_depreciation_rate=depreciation_rate
        )
        
        return category
