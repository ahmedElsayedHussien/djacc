from django.views.generic import TemplateView
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.utils import timezone
from django.core.paginator import Paginator
from datetime import date, datetime

from .services import ReportService
from apps.core.models import FiscalYear

def parse_date(date_val, default=None):
    if not date_val:
        return default or date.today()
    if isinstance(date_val, str):
        try:
            return datetime.strptime(date_val, '%Y-%m-%d').date()
        except ValueError:
            return default or date.today()
    return date_val

class FinancialReportDashboardView(LoginRequiredMixin, PermissionRequiredMixin, TemplateView):
    permission_required = 'core.view_account'
    template_name = 'reports/financial_dashboard.html'

class TrialBalanceView(LoginRequiredMixin, PermissionRequiredMixin, TemplateView):
    permission_required = 'core.view_account'
    template_name = 'reports/trial_balance.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        from_date = parse_date(self.request.GET.get('from'), date(date.today().year, 1, 1))
        to_date = parse_date(self.request.GET.get('to'), date.today())
        
        from apps.core.models import CostCenter
        context['cost_centers'] = CostCenter.objects.filter(is_active=True)
        cc_id = self.request.GET.get('cost_center')
        if cc_id:
            context['selected_cc'] = int(cc_id)
        
        rows = ReportService.trial_balance(from_date, to_date)
        context['rows'] = rows
        
        # Calculate totals
        totals = {
            'op_debit': sum(row['op_debit'] for row in rows),
            'op_credit': sum(row['op_credit'] for row in rows),
            'mov_debit': sum(row['mov_debit'] for row in rows),
            'mov_credit': sum(row['mov_credit'] for row in rows),
            'cl_debit': sum(row['cl_debit'] for row in rows),
            'cl_credit': sum(row['cl_credit'] for row in rows),
        }
        context['totals'] = totals
        
        context['from_date'] = from_date
        context['to_date'] = to_date
        return context

class IncomeStatementView(LoginRequiredMixin, PermissionRequiredMixin, TemplateView):
    permission_required = 'core.view_account'
    template_name = 'reports/income_statement.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        from_date = parse_date(self.request.GET.get('from'), date.today().replace(day=1))
        to_date = parse_date(self.request.GET.get('to'), date.today())

        from apps.core.models import CostCenter
        context['cost_centers'] = CostCenter.objects.filter(is_active=True)
        cc_id = self.request.GET.get('cost_center')
        cc_id_int = int(cc_id) if cc_id else None
        if cc_id_int:
            context['selected_cc'] = cc_id_int

        context['report'] = ReportService.income_statement(from_date, to_date, cost_center_id=cc_id_int)
        context['from_date'] = from_date
        context['to_date'] = to_date
        return context

class BalanceSheetView(LoginRequiredMixin, PermissionRequiredMixin, TemplateView):
    permission_required = 'core.view_account'
    template_name = 'reports/balance_sheet.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        as_of_date = parse_date(self.request.GET.get('date'), date.today())

        from apps.core.models import CostCenter
        context['cost_centers'] = CostCenter.objects.filter(is_active=True)
        cc_id = self.request.GET.get('cost_center')
        cc_id_int = int(cc_id) if cc_id else None
        if cc_id_int:
            context['selected_cc'] = cc_id_int

        context['report'] = ReportService.balance_sheet(as_of_date, cost_center_id=cc_id_int)
        context['as_of_date'] = as_of_date
        return context

class CustomerStatementView(LoginRequiredMixin, PermissionRequiredMixin, TemplateView):
    permission_required = 'sales.view_customer'
    template_name = 'reports/customer_statement.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        from apps.sales.models import Customer
        customer_id = self.request.GET.get('customer')
        from_date = parse_date(self.request.GET.get('from'), date.today().replace(day=1))
        to_date = parse_date(self.request.GET.get('to'), date.today())
        
        context['customers'] = Customer.objects.all()
        context['from_date'] = from_date
        context['to_date'] = to_date
        
        if customer_id:
            context['report'] = ReportService.customer_statement(int(customer_id), from_date, to_date)
            context['selected_customer'] = int(customer_id)
            
        return context
class SupplierStatementView(LoginRequiredMixin, PermissionRequiredMixin, TemplateView):
    permission_required = 'purchases.view_supplier'
    template_name = 'reports/supplier_statement.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        from apps.purchases.models import Supplier
        supplier_id = self.request.GET.get('supplier')
        from_date = parse_date(self.request.GET.get('from'), date.today().replace(day=1))
        to_date = parse_date(self.request.GET.get('to'), date.today())
        
        context['suppliers'] = Supplier.objects.all()
        context['from_date'] = from_date
        context['to_date'] = to_date
        
        if supplier_id:
            context['report'] = ReportService.supplier_statement(int(supplier_id), from_date, to_date)
            context['selected_supplier'] = int(supplier_id)
            
        return context

class RepStatementView(LoginRequiredMixin, PermissionRequiredMixin, TemplateView):
    permission_required = 'sales.view_salesrepresentative'
    template_name = 'reports/rep_statement.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        from apps.sales.models import SalesRepresentative
        rep_id = self.request.GET.get('rep')
        from_date = parse_date(self.request.GET.get('from'), date.today().replace(day=1))
        to_date = parse_date(self.request.GET.get('to'), date.today())
        
        context['reps'] = SalesRepresentative.objects.all()
        context['from_date'] = from_date
        context['to_date'] = to_date
        
        if rep_id:
            context['report'] = ReportService.rep_statement(int(rep_id), from_date, to_date)
            context['selected_rep'] = int(rep_id)
            
        return context

class StockStatusView(LoginRequiredMixin, PermissionRequiredMixin, TemplateView):
    permission_required = 'inventory.view_item'
    template_name = 'reports/stock_status.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        from apps.inventory.models import Warehouse
        warehouse_id = self.request.GET.get('warehouse')
        
        context['warehouses'] = Warehouse.objects.all()
        report_data = ReportService.stock_status(warehouse_id)
        
        paginator = Paginator(report_data['items'], 50)
        page_number = self.request.GET.get('page')
        report_data['items'] = paginator.get_page(page_number)
        
        context['report'] = report_data
        if warehouse_id:
            context['selected_warehouse'] = int(warehouse_id)


            
        return context

class RepCommissionView(LoginRequiredMixin, PermissionRequiredMixin, TemplateView):
    permission_required = 'sales.view_salesrepresentative'
    template_name = 'reports/rep_commission.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        from_date = parse_date(self.request.GET.get('from'), date.today().replace(day=1))
        to_date = parse_date(self.request.GET.get('to'), date.today())
        context['report'] = ReportService.rep_commission_report(from_date, to_date)
        context['from_date'] = from_date
        context['to_date'] = to_date
        return context

class CostCenterStatementView(LoginRequiredMixin, PermissionRequiredMixin, TemplateView):
    permission_required = 'core.view_costcenter'
    template_name = 'reports/cost_center_statement.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        from apps.core.models import CostCenter
        cost_center_id = self.request.GET.get('cost_center')
        from_date = parse_date(self.request.GET.get('from'), date.today().replace(day=1))
        to_date = parse_date(self.request.GET.get('to'), date.today())
        
        context['cost_centers'] = CostCenter.objects.all()
        context['from_date'] = from_date
        context['to_date'] = to_date
        
        if cost_center_id:
            context['report'] = ReportService.cost_center_statement(int(cost_center_id), from_date, to_date)
            context['selected_cost_center'] = int(cost_center_id)
            
        return context

class AccountStatementView(LoginRequiredMixin, PermissionRequiredMixin, TemplateView):
    permission_required = 'core.view_account'
    template_name = 'reports/account_statement.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        from apps.core.models import Account
        account_id = self.request.GET.get('account')
        from_date = parse_date(self.request.GET.get('from'), date.today().replace(day=1))
        to_date = parse_date(self.request.GET.get('to'), date.today())
        
        context['accounts'] = Account.objects.filter(is_leaf=True).order_by('code')
        context['from_date'] = from_date
        context['to_date'] = to_date
        
        if account_id:
            context['report'] = ReportService.account_statement(int(account_id), from_date, to_date)
            context['selected_account'] = int(account_id)
            
        return context


class VATReportView(LoginRequiredMixin, PermissionRequiredMixin, TemplateView):
    """
    تقرير ضريبة القيمة المضافة (VAT Report)
    يُظهر: ضريبة المبيعات (Output) + ضريبة المشتريات (Input) + صافي الضريبة
    """
    permission_required = 'core.view_account'
    template_name = 'reports/vat_report.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        from_date = parse_date(self.request.GET.get('from'), date.today().replace(day=1))
        to_date = parse_date(self.request.GET.get('to'), date.today())

        from apps.core.models import CostCenter
        context['cost_centers'] = CostCenter.objects.filter(is_active=True)
        cc_id = self.request.GET.get('cost_center')
        cc_id_int = int(cc_id) if cc_id else None
        if cc_id_int:
            context['selected_cc'] = cc_id_int

        context['report'] = ReportService.vat_report(from_date, to_date, cost_center_id=cc_id_int)
        context['from_date'] = from_date
        context['to_date'] = to_date
        return context


class WHTReportView(LoginRequiredMixin, PermissionRequiredMixin, TemplateView):
    """
    تقرير ضريبة الخصم والتحصيل (Withholding Tax Report)
    يُظهر: WHT على المبيعات + WHT على المشتريات + صافي القيمة
    """
    permission_required = 'core.view_account'
    template_name = 'reports/wht_report.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        from_date = parse_date(self.request.GET.get('from'), date.today().replace(day=1))
        to_date = parse_date(self.request.GET.get('to'), date.today())

        from apps.core.models import CostCenter
        context['cost_centers'] = CostCenter.objects.filter(is_active=True)
        cc_id = self.request.GET.get('cost_center')
        cc_id_int = int(cc_id) if cc_id else None
        if cc_id_int:
            context['selected_cc'] = cc_id_int

        context['report'] = ReportService.wht_report(from_date, to_date, cost_center_id=cc_id_int)
        context['from_date'] = from_date
        context['to_date'] = to_date
        return context

# --- Inventory Reports ---

class InventoryValuationView(LoginRequiredMixin, PermissionRequiredMixin, TemplateView):
    permission_required = 'inventory.view_item'
    template_name = 'reports/inventory_valuation.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        from apps.inventory.models import Warehouse
        warehouse_id = self.request.GET.get('warehouse')
        context['warehouses'] = Warehouse.objects.all()
        report_data = ReportService.inventory_valuation(warehouse_id)
        
        paginator = Paginator(report_data['items'], 50)
        page_number = self.request.GET.get('page')
        report_data['items'] = paginator.get_page(page_number)
        
        context['report'] = report_data
        if warehouse_id:
            context['selected_warehouse'] = int(warehouse_id)

        return context

class ReorderAlertView(LoginRequiredMixin, PermissionRequiredMixin, TemplateView):
    permission_required = 'inventory.view_item'
    template_name = 'reports/reorder_alert.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        report_qs = ReportService.reorder_alert_report()
        
        paginator = Paginator(report_qs, 50)
        page_number = self.request.GET.get('page')
        context['report'] = paginator.get_page(page_number)
        
        return context


class ItemLedgerReportView(LoginRequiredMixin, PermissionRequiredMixin, TemplateView):
    permission_required = 'inventory.view_item'
    template_name = 'reports/item_ledger.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        from apps.inventory.models import Item, Warehouse
        item_id = self.request.GET.get('item')
        warehouse_id = self.request.GET.get('warehouse')
        from_date = parse_date(self.request.GET.get('from'), date.today().replace(day=1))
        to_date = parse_date(self.request.GET.get('to'), date.today())

        context['items'] = Item.objects.filter(is_active=True).order_by('name')
        context['warehouses'] = Warehouse.objects.all()
        context['from_date'] = from_date
        context['to_date'] = to_date

        if item_id:
            report_data = ReportService.item_ledger_report(
                int(item_id), 
                int(warehouse_id) if warehouse_id else None,
                from_date,
                to_date
            )
            
            paginator = Paginator(report_data['movements'], 50)
            page_number = self.request.GET.get('page')
            report_data['movements'] = paginator.get_page(page_number)
            
            context['report'] = report_data
            context['selected_item'] = int(item_id)
            if warehouse_id:
                context['selected_warehouse'] = int(warehouse_id)

        
        return context

class WastageAdjustmentsView(LoginRequiredMixin, PermissionRequiredMixin, TemplateView):
    permission_required = 'inventory.view_stockvoucher'
    template_name = 'reports/wastage_adjustments.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        from_date = parse_date(self.request.GET.get('from'), date.today().replace(day=1))
        to_date = parse_date(self.request.GET.get('to'), date.today())
        report_qs = ReportService.wastage_adjustments_report(from_date, to_date)
        
        paginator = Paginator(report_qs, 50)
        page_number = self.request.GET.get('page')
        context['report'] = paginator.get_page(page_number)
        
        context['from_date'] = from_date
        context['to_date'] = to_date
        return context


class VanInventoryView(LoginRequiredMixin, PermissionRequiredMixin, TemplateView):
    permission_required = 'sales.view_salesrepresentative'
    template_name = 'reports/van_inventory.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        from apps.sales.models import SalesRepresentative
        rep_id = self.request.GET.get('rep')
        context['reps'] = SalesRepresentative.objects.filter(is_active=True)
        
        if rep_id:
            try:
                report_data = ReportService.van_inventory_report(int(rep_id))
                
                paginator = Paginator(report_data['items'], 50)
                page_number = self.request.GET.get('page')
                report_data['items'] = paginator.get_page(page_number)
                
                context['report'] = report_data
                context['selected_rep'] = int(rep_id)
            except Exception as e:
                context['error'] = str(e)

        return context

class InventoryTurnoverView(LoginRequiredMixin, PermissionRequiredMixin, TemplateView):
    permission_required = 'inventory.view_item'
    template_name = 'reports/inventory_turnover.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        from_date = parse_date(self.request.GET.get('from'), date(date.today().year, 1, 1))
        to_date = parse_date(self.request.GET.get('to'), date.today())
        report_list = ReportService.inventory_turnover_report(from_date, to_date)
        
        paginator = Paginator(report_list, 50)
        page_number = self.request.GET.get('page')
        context['report'] = paginator.get_page(page_number)
        
        context['from_date'] = from_date
        context['to_date'] = to_date
        return context


class SalesRepDashboardView(LoginRequiredMixin, PermissionRequiredMixin, TemplateView):
    permission_required = 'sales.view_salesrepresentative'
    template_name = 'reports/rep_dashboard.html'

    def dispatch(self, request, *args, **kwargs):
        if not request.user.is_authenticated:
            return super().dispatch(request, *args, **kwargs)
            
        is_rep = hasattr(request.user, 'salesrepresentative')
        is_admin = request.user.is_superuser or request.user.is_staff
        
        if not (is_rep or is_admin):
            from django.core.exceptions import PermissionDenied
            raise PermissionDenied("ليس لديك صلاحية للوصول إلى هذه لوحة التحكم.")
            
        return super().dispatch(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        from apps.sales.models import SalesRepresentative, SalesInvoice, SalesTarget, CustomerReceipt, RepDailySettlement
        from apps.inventory.models import ItemLedger
        from django.db.models import Sum, Q
        from decimal import Decimal
        from datetime import date
        
        # 1. Determine active representative
        user = self.request.user
        rep = None
        
        # Check if the user is a sales representative
        if hasattr(user, 'salesrepresentative'):
            rep = user.salesrepresentative
            context['is_representative'] = True
        else:
            # Check if there is a 'rep' parameter in the URL/GET
            rep_id = self.request.GET.get('rep')
            if rep_id:
                try:
                    rep = SalesRepresentative.objects.get(id=int(rep_id))
                except (ValueError, SalesRepresentative.DoesNotExist):
                    pass
            context['is_representative'] = False
            context['reps'] = SalesRepresentative.objects.filter(is_active=True)

        context['selected_rep'] = rep

        if rep:
            today = date.today()
            start_of_month = date(today.year, today.month, 1)
            
            # Get selected date from GET parameter, default to today
            selected_date_str = self.request.GET.get('date')
            selected_date = today
            if selected_date_str:
                try:
                    from datetime import datetime
                    selected_date = datetime.strptime(selected_date_str, '%Y-%m-%d').date()
                except ValueError:
                    pass
            context['selected_date'] = selected_date
            context['selected_date_str'] = selected_date_str
            
            # --- KPI Calculations ---
            # Safe Balance
            safe_balance = rep.cash_box.current_balance if rep.cash_box else Decimal('0')
            context['safe_balance'] = safe_balance
            
            # Van Inventory Value
            van_items = ItemLedger.objects.filter(warehouse=rep.warehouse).select_related('item', 'item__category').order_by('item__name')
            van_inventory_value = van_items.aggregate(total=Sum('total_value'))['total'] or Decimal('0')
            context['van_items'] = van_items
            context['van_inventory_value'] = van_inventory_value
            
            # Today's Sales
            sales_today = SalesInvoice.objects.filter(
                sales_rep=rep,
                status=SalesInvoice.Status.POSTED,
                date=today
            ).aggregate(total=Sum('total'))['total'] or Decimal('0')
            context['sales_today'] = sales_today
            
            # Current Month Sales
            sales_this_month = SalesInvoice.objects.filter(
                sales_rep=rep,
                status=SalesInvoice.Status.POSTED,
                date__range=[start_of_month, today]
            ).aggregate(total=Sum('total'))['total'] or Decimal('0')
            context['sales_this_month'] = sales_this_month
            
            # Returns Calculations (Today & Current Month)
            from apps.sales.models import SalesReturn
            returns_today = SalesReturn.objects.filter(
                sales_rep=rep,
                status=SalesReturn.Status.POSTED,
                date=today
            ).aggregate(total=Sum('total'))['total'] or Decimal('0')
            context['returns_today'] = returns_today
            
            returns_this_month = SalesReturn.objects.filter(
                sales_rep=rep,
                status=SalesReturn.Status.POSTED,
                date__range=[start_of_month, today]
            ).aggregate(total=Sum('total'))['total'] or Decimal('0')
            context['returns_this_month'] = returns_this_month
            
            # Monthly Target Progress
            target = SalesTarget.objects.filter(
                sales_rep=rep,
                start_date__lte=today,
                end_date__gte=today
            ).first()
            
            context['target'] = target
            if target and target.target_amount > 0:
                context['target_amount'] = target.target_amount
                context['target_achievement'] = min(int((sales_this_month / target.target_amount) * 100), 100)
            else:
                context['target_amount'] = Decimal('0')
                context['target_achievement'] = None
                
            # Estimated Commission
            commission_rate = rep.commission_rate or Decimal('0')
            context['commission_rate'] = commission_rate
            context['commission_earned'] = (sales_this_month * commission_rate) / Decimal('100')
            
            # --- Cash Box Transactions (حساب الخزنة) ---
            # Daily statement only: from selected_date to selected_date
            if rep.cash_box and rep.cash_box.account:
                cash_box_statement = ReportService.account_statement(rep.cash_box.account.id, selected_date, selected_date)
                context['cash_box_statement'] = cash_box_statement
            
            # --- Lists for Recent Activity ---
            # Recent Sales Invoices (last 10)
            recent_invoices = SalesInvoice.objects.filter(sales_rep=rep).order_by('-date', '-id')[:10]
            context['recent_invoices'] = recent_invoices
            
            # Recent Sales Returns (last 10)
            from apps.sales.models import SalesReturn
            recent_returns = SalesReturn.objects.filter(sales_rep=rep).order_by('-date', '-id')[:10]
            context['recent_returns'] = recent_returns
            
            # Recent Customer Receipts (last 10)
            if rep.cash_box:
                recent_receipts = CustomerReceipt.objects.filter(cash_box=rep.cash_box).order_by('-date', '-id')[:10]
                context['recent_receipts'] = recent_receipts
                
            # Recent Daily Settlements
            recent_settlements = RepDailySettlement.objects.filter(sales_rep=rep).order_by('-date', '-id')[:10]
            context['recent_settlements'] = recent_settlements

        return context



