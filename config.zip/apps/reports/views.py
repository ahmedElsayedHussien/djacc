from django.views.generic import TemplateView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.utils import timezone
from datetime import date
from .services import ReportService
from apps.core.models import FiscalYear

class TrialBalanceView(LoginRequiredMixin, TemplateView):
    template_name = 'reports/trial_balance.html'

    def get_context_data(self, **kwargs):
        from datetime import datetime
        context = super().get_context_data(**kwargs)
        from_date_str = self.request.GET.get('from', date(date.today().year, 1, 1).strftime('%Y-%m-%d'))
        to_date_str = self.request.GET.get('to', timezone.now().date().strftime('%Y-%m-%d'))
        
        from_date = datetime.strptime(from_date_str, '%Y-%m-%d').date()
        to_date = datetime.strptime(to_date_str, '%Y-%m-%d').date()
        
        from apps.core.models import CostCenter
        context['cost_centers'] = CostCenter.objects.filter(is_active=True)
        cc_id = self.request.GET.get('cost_center')
        if cc_id:
            context['selected_cc'] = int(cc_id)
        
        context['rows'] = ReportService.trial_balance(from_date, to_date)
        context['from_date'] = from_date
        context['to_date'] = to_date
        return context

class IncomeStatementView(LoginRequiredMixin, TemplateView):
    template_name = 'reports/income_statement.html'

    def get_context_data(self, **kwargs):
        from datetime import datetime
        context = super().get_context_data(**kwargs)
        from_date_str = self.request.GET.get('from', timezone.now().replace(day=1).date().strftime('%Y-%m-%d'))
        to_date_str = self.request.GET.get('to', timezone.now().date().strftime('%Y-%m-%d'))
        
        if isinstance(from_date_str, str):
            from_date = datetime.strptime(from_date_str, '%Y-%m-%d').date()
        else:
            from_date = from_date_str
            
        if isinstance(to_date_str, str):
            to_date = datetime.strptime(to_date_str, '%Y-%m-%d').date()
        else:
            to_date = to_date_str

        from apps.core.models import CostCenter
        context['cost_centers'] = CostCenter.objects.filter(is_active=True)
        cc_id = self.request.GET.get('cost_center')
        if cc_id:
            context['selected_cc'] = int(cc_id)

        context['report'] = ReportService.income_statement(from_date, to_date, cost_center_id=cc_id)
        context['from_date'] = from_date
        context['to_date'] = to_date
        return context

class BalanceSheetView(LoginRequiredMixin, TemplateView):
    template_name = 'reports/balance_sheet.html'

    def get_context_data(self, **kwargs):
        from datetime import datetime
        context = super().get_context_data(**kwargs)
        as_of_date_str = self.request.GET.get('date', timezone.now().date().strftime('%Y-%m-%d'))
        
        if isinstance(as_of_date_str, str):
            as_of_date = datetime.strptime(as_of_date_str, '%Y-%m-%d').date()
        else:
            as_of_date = as_of_date_str

        from apps.core.models import CostCenter
        context['cost_centers'] = CostCenter.objects.filter(is_active=True)
        cc_id = self.request.GET.get('cost_center')
        if cc_id:
            context['selected_cc'] = int(cc_id)

        context['report'] = ReportService.balance_sheet(as_of_date, cost_center_id=cc_id)
        context['as_of_date'] = as_of_date
        return context

class CustomerStatementView(LoginRequiredMixin, TemplateView):
    template_name = 'reports/customer_statement.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        from apps.sales.models import Customer
        customer_id = self.request.GET.get('customer')
        from_date = self.request.GET.get('from', timezone.now().replace(day=1).date())
        to_date = self.request.GET.get('to', timezone.now().date())
        
        context['customers'] = Customer.objects.all()
        context['from_date'] = from_date
        context['to_date'] = to_date
        
        if customer_id:
            context['report'] = ReportService.customer_statement(int(customer_id), from_date, to_date)
            context['selected_customer'] = int(customer_id)
            
        return context

class StockStatusView(LoginRequiredMixin, TemplateView):
    template_name = 'reports/stock_status.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        from apps.inventory.models import Warehouse
        warehouse_id = self.request.GET.get('warehouse')
        
        context['warehouses'] = Warehouse.objects.all()
        context['report'] = ReportService.stock_status(warehouse_id)
        if warehouse_id:
            context['selected_warehouse'] = int(warehouse_id)
            
        return context

class RepCommissionView(LoginRequiredMixin, TemplateView):
    template_name = 'reports/rep_commission.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        from_date = self.request.GET.get('from', timezone.now().replace(day=1).date())
        to_date = self.request.GET.get('to', timezone.now().date())
        context['report'] = ReportService.rep_commission_report(from_date, to_date)
        context['from_date'] = from_date
        context['to_date'] = to_date
        return context

class CostCenterStatementView(LoginRequiredMixin, TemplateView):
    template_name = 'reports/cost_center_statement.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        from apps.core.models import CostCenter
        cost_center_id = self.request.GET.get('cost_center')
        from_date = self.request.GET.get('from', timezone.now().replace(day=1).date())
        to_date = self.request.GET.get('to', timezone.now().date())
        
        context['cost_centers'] = CostCenter.objects.all()
        context['from_date'] = from_date
        context['to_date'] = to_date
        
        if cost_center_id:
            context['report'] = ReportService.cost_center_statement(int(cost_center_id), from_date, to_date)
            context['selected_cost_center'] = int(cost_center_id)
            
        return context

class AccountStatementView(LoginRequiredMixin, TemplateView):
    template_name = 'reports/account_statement.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        from apps.core.models import Account
        account_id = self.request.GET.get('account')
        from_date = self.request.GET.get('from', timezone.now().replace(day=1).date())
        to_date = self.request.GET.get('to', timezone.now().date())
        
        context['accounts'] = Account.objects.filter(is_leaf=True).order_by('code')
        context['from_date'] = from_date
        context['to_date'] = to_date
        
        if account_id:
            context['report'] = ReportService.account_statement(int(account_id), from_date, to_date)
            context['selected_account'] = int(account_id)
            
        return context
