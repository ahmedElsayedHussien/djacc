from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from apps.sales.models import SalesInvoice, Customer
from apps.purchases.models import PurchaseInvoice
from apps.inventory.models import Item, ItemLedger
from apps.core.models import JournalEntry, AuditLog, Account, JournalLine, SystemNotification
from django.utils import timezone
from django.db.models import Sum, Q, F
from decimal import Decimal
from django.conf import settings

@login_required
def dashboard(request):
    if hasattr(request.user, 'salesrepresentative') and not request.user.is_superuser and not request.user.is_staff:
        return redirect('reports:rep_dashboard')
        
    today = timezone.now().date()
    first_day_of_month = today.replace(day=1)
    
    # ==========================
    # 1. Sales & Purchases (MTD)
    # ==========================
    mtd_sales = SalesInvoice.objects.filter(
        date__gte=first_day_of_month, status='posted'
    ).aggregate(total=Sum('total'))['total'] or Decimal('0')
    
    mtd_purchases = PurchaseInvoice.objects.filter(
        date__gte=first_day_of_month, status='posted'
    ).aggregate(total=Sum('total'))['total'] or Decimal('0')
    
    # ==========================
    # 2. Finance & Treasury
    # ==========================
    def get_parent_balance(parent_code):
        accounts = Account.objects.filter(parent__code=parent_code, is_leaf=True)
        total = Decimal('0')
        for acc in accounts:
            stats = JournalLine.objects.filter(account=acc, entry__is_posted=True).aggregate(d=Sum('debit'), c=Sum('credit'))
            debit = stats['d'] or Decimal('0')
            credit = stats['c'] or Decimal('0')
            # Check opening balance
            has_opening = JournalLine.objects.filter(account=acc, entry__entry_type=JournalEntry.EntryType.OPENING, entry__is_posted=True).exists()
            if not has_opening:
                if acc.initial_balance_type == 'debit':
                    debit += acc.initial_balance
                else:
                    credit += acc.initial_balance
            total += (debit - credit)
        return total

    # Total Cash & Bank Liquidity
    total_cash = get_parent_balance(getattr(settings, 'CASH_PARENT_ACCOUNT', '1111'))
    total_bank = get_parent_balance(getattr(settings, 'BANK_PARENT_ACCOUNT', '1112'))
    total_liquidity = total_cash + total_bank
    
    # Receivables (What customers owe us) & Payables (What we owe suppliers)
    total_receivables = get_parent_balance(getattr(settings, 'CUSTOMERS_PARENT_ACCOUNT', '1121'))
    total_payables = get_parent_balance(getattr(settings, 'SUPPLIERS_PARENT_ACCOUNT', '2111')) * Decimal('-1')

    # ==========================
    # 3. Inventory KPIs
    # ==========================
    # Total Inventory Value (Current Cost)
    inventory_value = ItemLedger.objects.aggregate(total=Sum('total_value'))['total'] or Decimal('0')
    
    low_stock = ItemLedger.objects.values('item__name', 'item__minimum_stock').annotate(
        total_qty=Sum('quantity_on_hand')
    ).filter(total_qty__lt=F('item__minimum_stock'))[:5]
    low_stock_count = low_stock.count()

    # ==========================
    # 4. HR KPIs
    # ==========================
    from apps.hr.models import Employee
    active_employees = Employee.objects.filter(status='active').count()
    payroll_load = Employee.objects.filter(status='active').aggregate(total=Sum('basic_salary'))['total'] or Decimal('0')
    
    context = {
        # Financials
        'total_liquidity': total_liquidity,
        'total_receivables': total_receivables,
        'total_payables': total_payables,
        # Sales & Purchases
        'mtd_sales': mtd_sales,
        'mtd_purchases': mtd_purchases,
        # Inventory
        'inventory_value': inventory_value,
        'low_stock': low_stock,
        'low_stock_count': low_stock_count,
        # HR
        'active_employees': active_employees,
        'payroll_load': payroll_load,
        # General Logs
        'recent_entries': JournalEntry.objects.order_by('-id')[:5],
        'recent_logs': AuditLog.objects.select_related('user', 'content_type').order_by('-timestamp')[:5],
    }
    return render(request, 'core/dashboard.html', context)


@login_required
def notification_read(request, pk):
    from django.shortcuts import get_object_or_404
    from apps.core.models import SystemNotification
    
    notification = get_object_or_404(SystemNotification, pk=pk, recipient=request.user)
    notification.is_read = True
    notification.save()
    
    if notification.url:
        return redirect(notification.url)
    return redirect('core:dashboard')


from django.views.generic import ListView
from django.contrib.auth.mixins import LoginRequiredMixin

class NotificationListView(LoginRequiredMixin, ListView):
    model = SystemNotification
    template_name = 'core/notifications/list.html'
    context_object_name = 'notifications'
    paginate_by = 20

    def get_queryset(self):
        return SystemNotification.objects.filter(recipient=self.request.user).order_by('-created_at')


@login_required
def mark_all_notifications_read(request):
    from django.contrib import messages
    from apps.core.models import SystemNotification
    SystemNotification.objects.filter(recipient=request.user, is_read=False).update(is_read=True)
    messages.success(request, "تم تحديد جميع الإشعارات كمقروءة بنجاح.")
    return redirect('core:notification-list')
