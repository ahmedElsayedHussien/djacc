from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from apps.sales.models import SalesInvoice, Customer
from apps.purchases.models import PurchaseInvoice
from apps.inventory.models import Item
from apps.core.models import JournalEntry, AuditLog, Account
from apps.inventory.models import ItemLedger
from django.utils import timezone
from django.db.models import Sum
from decimal import Decimal
from django.conf import settings

@login_required
def dashboard(request):
    today = timezone.now().date()
    
    # 1. Today's Sales
    today_sales = SalesInvoice.objects.filter(
        date=today, status='posted'
    ).aggregate(total=Sum('total'))['total'] or Decimal('0')
    
    # 2. Total Cash (Sum of balances of all CashBox accounts)
    from django.db.models import Q
    cash_parent = getattr(settings, 'CASH_PARENT_ACCOUNT', '1111')
    cash_accounts = Account.objects.filter(parent__code=cash_parent, is_leaf=True)
    
    cash_stats = cash_accounts.aggregate(
        total_debits=Sum('journal_lines__debit', filter=Q(journal_lines__entry__is_posted=True)),
        total_credits=Sum('journal_lines__credit', filter=Q(journal_lines__entry__is_posted=True)),
        init_debit=Sum('initial_balance', filter=Q(initial_balance_type='debit')),
        init_credit=Sum('initial_balance', filter=Q(initial_balance_type='credit'))
    )
    
    total_cash = (
        (cash_stats['total_debits'] or Decimal('0')) + 
        (cash_stats['init_debit'] or Decimal('0')) - 
        (cash_stats['total_credits'] or Decimal('0')) - 
        (cash_stats['init_credit'] or Decimal('0'))
    )
    
    # 3. Low Stock Items (Quantity < 10)
    low_stock = ItemLedger.objects.values('item__name').annotate(
        total_qty=Sum('quantity_on_hand')
    ).filter(total_qty__lt=10)[:5]
    
    context = {
        'total_sales': SalesInvoice.objects.filter(status='posted').count(),
        'today_sales_amount': today_sales,
        'total_cash': total_cash,
        'total_purchases': PurchaseInvoice.objects.count(),
        'total_customers': Customer.objects.count(),
        'total_items': Item.objects.count(),
        'recent_entries': JournalEntry.objects.order_by('-id')[:5],
        'recent_logs': AuditLog.objects.select_related('user', 'content_type').order_by('-timestamp')[:5],
        'low_stock': low_stock,
    }
    return render(request, 'core/dashboard.html', context)
