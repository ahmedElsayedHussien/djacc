from django.core.management.base import BaseCommand
from django.contrib.auth.models import Group, Permission
from django.contrib.contenttypes.models import ContentType

class Command(BaseCommand):
    help = 'Setup default groups and permissions for the ERP system'

    def handle(self, *args, **options):
        # Define Group configurations
        GROUPS_CONFIG = {
            'سوبر ادمن': {
                'all': True
            },
            'مدير حسابات': {
                'permissions': [
                    ('core', ['account', 'journalentry', 'costcenter', 'taxtype', 'cashbox']),
                    ('treasury', ['cashbox', 'bankaccount', 'banktransaction', 'bankreconciliation', 'cashtransfer']),
                    ('expenses', ['expensecategory', 'expenseclaim']),
                    ('sales', ['customerreceipt']),
                    ('purchases', ['supplierpayment']),
                    ('reports', ['reportdefinition', 'reportexecution']),
                ]
            },
            'حسابات': {
                'permissions': [
                    ('core', ['journalentry', 'account']),
                    ('treasury', ['banktransaction', 'cashtransfer']),
                    ('expenses', ['expenseclaim']),
                    ('sales', ['customerreceipt']),
                    ('purchases', ['supplierpayment']),
                ]
            },
            'مدير مبيعات': {
                'permissions': [
                    ('sales', ['customer', 'salesinvoice', 'salesreturn', 'customerreceipt', 'quotation', 'pricelist', 'salesrepresentative', 'customersector']),
                    ('inventory', ['item', 'warehouse']),
                ]
            },
            'مبيعات': {
                'permissions': [
                    ('sales', ['customer', 'salesinvoice', 'salesreturn', 'quotation', 'salesrepresentative']),
                ]
            },
            'مدير مخازن': {
                'permissions': [
                    ('inventory', ['item', 'warehouse', 'unitofmeasure', 'stockmovement', 'itemledger', 'loadingorder', 'transfer']),
                ]
            },
            'مخازن': {
                'permissions': [
                    ('inventory', ['item', 'warehouse', 'stockmovement', 'loadingorder', 'transfer']),
                ]
            },
            'مدير it': {
                'permissions': [
                    ('core', ['account', 'journalentry', 'costcenter', 'taxtype', 'cashbox']),
                    ('reports', ['reportdefinition', 'reportexecution']),
                ]
            },
            'it': {
                'permissions': [
                    ('core', ['taxtype']),
                ]
            },
            'مدير اداري': {
                'permissions': [
                    ('hr', ['employee', 'department', 'position', 'payrollperiod', 'salaryslip', 'leaverequest', 'employeeloan', 'eossettlement', 'attendance', 'holiday', 'contract']),
                ]
            },
            'اداريين': {
                'permissions': [
                    ('hr', ['employee', 'attendance', 'leaverequest']),
                ]
            },
            'مدير مشتريات': {
                'permissions': [
                    ('purchases', ['supplier', 'purchaseinvoice', 'purchasereturn', 'supplierpayment']),
                    ('inventory', ['item', 'warehouse']),
                ]
            },
            'مشتريات': {
                'permissions': [
                    ('purchases', ['supplier', 'purchaseinvoice', 'purchasereturn']),
                ]
            }
        }

        for group_name, config in GROUPS_CONFIG.items():
            group, created = Group.objects.get_or_create(name=group_name)
            if created:
                self.stdout.write(self.style.SUCCESS(f'Created group: {group_name}'))
            else:
                self.stdout.write(f'Updating group: {group_name}')

            if config.get('all'):
                permissions = Permission.objects.all()
                group.permissions.set(permissions)
                self.stdout.write(self.style.SUCCESS(f'Assigned all permissions to {group_name}'))
                continue

            group_permissions = []
            for app_label, models in config.get('permissions', []):
                for model_name in models:
                    try:
                        content_type = ContentType.objects.get(app_label=app_label, model=model_name.lower())
                        perms = Permission.objects.filter(content_type=content_type)
                        group_permissions.extend(perms)
                    except ContentType.DoesNotExist:
                        self.stdout.write(self.style.WARNING(f'ContentType not found for {app_label}.{model_name}'))

            group.permissions.set(group_permissions)
            self.stdout.write(self.style.SUCCESS(f'Assigned {len(group_permissions)} permissions to {group_name}'))

        # 🏢 إنشاء الإدارات تلقائياً بنفس أسماء الجروبات الـ 12 المحددة
        self.stdout.write(self.style.NOTICE('\nSetting up Departments corresponding to Groups...'))
        try:
            from apps.hr.models import Department
            for group_name in GROUPS_CONFIG.keys():
                dept, created = Department.objects.get_or_create(name=group_name)
                if created:
                    self.stdout.write(self.style.SUCCESS(f'Created department: {group_name}'))
                else:
                    self.stdout.write(f'Department already exists: {group_name}')
        except Exception as e:
            self.stdout.write(self.style.WARNING(f'Failed to setup departments: {str(e)}'))

        # 💼 إنشاء المسميات الوظيفية تلقائياً المقابلة لكل مجموعة
        self.stdout.write(self.style.NOTICE('\nSetting up Job Titles corresponding to Groups...'))
        try:
            from apps.hr.models import JobTitle
            JOB_INPUT_MAP = {
                'سوبر admin': 'سوبر ادمن',
                'سوبر ادمن': 'سوبر ادمن',
                'مدير حسابات': 'مدير حسابات',
                'حسابات': 'محاسب',
                'مدير مبيعات': 'مدير مبيعات',
                'مبيعات': 'مندوب مبيعات',
                'مدير مخازن': 'مدير مخازن',
                'مخازن': 'أمين مخزن',
                'مدير it': 'مدير IT',
                'it': 'تقني IT',
                'مدير اداري': 'مدير إداري',
                'اداريين': 'موظف إداري',
                'مدير مشتريات': 'مدير مشتريات',
                'مشتريات': 'مسؤول مشتريات'
            }
            for group_name, job_name in JOB_INPUT_MAP.items():
                job, created = JobTitle.objects.get_or_create(name=job_name)
                # ربط المسمى الوظيفي بالإدارة المطابقة تلقائياً
                dept = Department.objects.filter(name=group_name).first()
                if dept:
                    job.department = dept
                    job.save(update_fields=['department'])
                    self.stdout.write(self.style.SUCCESS(f'Associated job title: {job_name} with department: {group_name}'))
                elif created:
                    self.stdout.write(self.style.SUCCESS(f'Created job title: {job_name}'))
                else:
                    self.stdout.write(f'Job title already exists: {job_name}')
        except Exception as e:
            self.stdout.write(self.style.WARNING(f'Failed to setup job titles: {str(e)}'))

        self.stdout.write(self.style.SUCCESS('\nPermissions, Departments & Job Titles setup completed successfully.'))
