from django.contrib import admin
from .models import Customer, SalesInvoice, SalesInvoiceLine, CustomerReceipt, ReceiptAllocation

class SalesInvoiceLineInline(admin.TabularInline):
    model = SalesInvoiceLine
    extra = 1

@admin.register(Customer)
class CustomerAdmin(admin.ModelAdmin):
    list_display = ('code', 'name', 'account', 'phone')
    search_fields = ('code', 'name')

@admin.register(SalesInvoice)
class SalesInvoiceAdmin(admin.ModelAdmin):
    list_display = ('number', 'date', 'customer', 'total', 'status')
    list_filter = ('status', 'date')
    inlines = [SalesInvoiceLineInline]
    readonly_fields = ('journal_entry',)

@admin.register(CustomerReceipt)
class CustomerReceiptAdmin(admin.ModelAdmin):
    list_display = ('number', 'date', 'customer', 'amount', 'payment_method')
    list_filter = ('payment_method', 'date')
