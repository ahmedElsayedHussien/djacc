from django import forms
from django.forms import inlineformset_factory
from .models import Customer, SalesInvoice, SalesInvoiceLine, CustomerReceipt, SalesRepresentative, IntermediaryCompany
from apps.inventory.models import Item, Warehouse

class CustomerForm(forms.ModelForm):
    class Meta:
        model = Customer
        fields = [
            'code', 'name', 'tax_number',
            'credit_limit', 'payment_terms_days',
            'address', 'phone', 'email', 'customer_type', 'price_list',
        ]
        widgets = {
            'code': forms.TextInput(attrs={'class': 'form-control'}),
            'name': forms.TextInput(attrs={'class': 'form-control'}),
            'tax_number': forms.TextInput(attrs={'class': 'form-control'}),
            'credit_limit': forms.NumberInput(attrs={'class': 'form-control'}),
            'payment_terms_days': forms.NumberInput(attrs={'class': 'form-control'}),
            'address': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
            'phone': forms.TextInput(attrs={'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
            'customer_type': forms.Select(attrs={'class': 'form-select'}),
            'price_list': forms.Select(attrs={'class': 'form-select'}),
        }

class SalesRepresentativeForm(forms.ModelForm):
    class Meta:
        model = SalesRepresentative
        fields = ['code', 'name', 'user', 'phone', 'commission_rate', 'territory', 'supervisor', 'is_active']
        widgets = {
            'code': forms.TextInput(attrs={'class': 'form-control'}),
            'name': forms.TextInput(attrs={'class': 'form-control'}),
            'user': forms.Select(attrs={'class': 'form-select'}),
            'phone': forms.TextInput(attrs={'class': 'form-control'}),
            'commission_rate': forms.NumberInput(attrs={'class': 'form-control', 'step': 'any'}),
            'territory': forms.TextInput(attrs={'class': 'form-control'}),
            'supervisor': forms.Select(attrs={'class': 'form-select'}),
            'is_active': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        }

class SalesInvoiceForm(forms.ModelForm):
    class Meta:
        model = SalesInvoice
        fields = ['number', 'date', 'customer', 'payment_type', 'sales_rep', 'cash_box', 'cost_center', 'due_date', 'notes']
        widgets = {
            'number': forms.TextInput(attrs={'class': 'form-control', 'readonly': 'readonly'}),
            'date': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'customer': forms.Select(attrs={'class': 'form-select'}),
            'payment_type': forms.Select(attrs={'class': 'form-select'}),
            'sales_rep': forms.Select(attrs={'class': 'form-select'}),
            'cash_box': forms.Select(attrs={'class': 'form-select'}),
            'cost_center': forms.Select(attrs={'class': 'form-select'}),
            'due_date': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'notes': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
        }

class SalesInvoiceLineForm(forms.ModelForm):
    class Meta:
        model = SalesInvoiceLine
        fields = ['item', 'warehouse', 'unit', 'quantity', 'unit_price', 'discount_percent', 'tax_type', 'tax_percent', 'total']
        widgets = {
            'item': forms.Select(attrs={'class': 'form-select item-select'}),
            'warehouse': forms.Select(attrs={'class': 'form-select'}),
            'unit': forms.Select(attrs={'class': 'form-select unit-select'}),
            'quantity': forms.NumberInput(attrs={'class': 'form-control qty-input', 'step': 'any'}),
            'unit_price': forms.NumberInput(attrs={'class': 'form-control price-input', 'step': 'any'}),
            'discount_percent': forms.NumberInput(attrs={'class': 'form-control discount-input', 'step': 'any'}),
            'tax_type': forms.Select(attrs={'class': 'form-select tax-select'}),
            'total': forms.HiddenInput(attrs={'class': 'total-input'}),
        }

SalesInvoiceLineFormSet = inlineformset_factory(
    SalesInvoice, SalesInvoiceLine,
    form=SalesInvoiceLineForm,
    extra=1,
    can_delete=True
)

class CustomerReceiptForm(forms.ModelForm):
    class Meta:
        model = CustomerReceipt
        fields = [
            'date', 'customer', 'amount', 'payment_method', 
            'bank_account', 'cash_box', 'intermediary_company',
            'cheque_number', 'cheque_due_date', 'reference'
        ]
        widgets = {
            'date': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'customer': forms.Select(attrs={'class': 'form-select'}),
            'amount': forms.NumberInput(attrs={'class': 'form-control', 'step': 'any'}),
            'payment_method': forms.Select(attrs={'class': 'form-select'}),
            'bank_account': forms.Select(attrs={'class': 'form-select'}),
            'cash_box': forms.Select(attrs={'class': 'form-select'}),
            'intermediary_company': forms.Select(attrs={'class': 'form-select'}),
            'cheque_number': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'رقم الشيك'}),
            'cheque_due_date': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'reference': forms.TextInput(attrs={'class': 'form-control'}),
        }

    def clean(self):
        cleaned = super().clean()
        method = cleaned.get('payment_method')
        
        if method == 'bank' and not cleaned.get('bank_account'):
            raise forms.ValidationError('يجب تحديد الحساب البنكي عند الدفع بالبنك')
        
        if method == 'cheque':
            if not cleaned.get('cheque_number'):
                raise forms.ValidationError('يجب إدخال رقم الشيك')
            if not cleaned.get('cheque_due_date'):
                raise forms.ValidationError('يجب إدخال تاريخ استحقاق الشيك')
                
        return cleaned

from .models import SalesReturn, SalesReturnLine, Quotation, QuotationLine

class QuotationForm(forms.ModelForm):
    class Meta:
        model = Quotation
        fields = ['date', 'expiry_date', 'customer', 'sales_rep', 'notes']
        widgets = {
            'date': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'expiry_date': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'customer': forms.Select(attrs={'class': 'form-select'}),
            'sales_rep': forms.Select(attrs={'class': 'form-select'}),
            'notes': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
        }

class QuotationLineForm(forms.ModelForm):
    class Meta:
        model = QuotationLine
        fields = ['item', 'quantity', 'unit_price', 'discount_percent', 'tax_type', 'tax_percent']
        widgets = {
            'item': forms.Select(attrs={'class': 'form-select'}),
            'quantity': forms.NumberInput(attrs={'class': 'form-control', 'step': 'any'}),
            'unit_price': forms.NumberInput(attrs={'class': 'form-control', 'step': 'any'}),
            'discount_percent': forms.NumberInput(attrs={'class': 'form-control', 'step': 'any'}),
            'tax_type': forms.Select(attrs={'class': 'form-select'}),
        }

QuotationLineFormSet = inlineformset_factory(
    Quotation, QuotationLine,
    form=QuotationLineForm,
    extra=1,
    can_delete=True
)

class SalesReturnLineForm(forms.ModelForm):
    class Meta:
        model = SalesReturnLine
        fields = ['item', 'warehouse', 'quantity', 'unit_price', 'tax_type', 'tax_percent', 'total', 'return_account', 'cogs_account']
        widgets = {
            'item': forms.Select(attrs={'class': 'form-select'}),
            'warehouse': forms.Select(attrs={'class': 'form-select'}),
            'quantity': forms.NumberInput(attrs={'class': 'form-control', 'step': 'any'}),
            'unit_price': forms.NumberInput(attrs={'class': 'form-control', 'step': 'any'}),
            'tax_type': forms.Select(attrs={'class': 'form-select'}),
            'total': forms.NumberInput(attrs={'class': 'form-control', 'readonly': 'readonly'}),
            'return_account': forms.Select(attrs={'class': 'form-select'}),
            'cogs_account': forms.Select(attrs={'class': 'form-select'}),
        }

SalesReturnLineFormSet = inlineformset_factory(
    SalesReturn, SalesReturnLine,
    form=SalesReturnLineForm,
    extra=1,
    can_delete=True
)
