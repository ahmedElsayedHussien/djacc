from django.views.generic import ListView, CreateView, UpdateView, DetailView
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.urls import reverse_lazy, reverse
from django.contrib import messages
from django.shortcuts import get_object_or_404, redirect
from django.db import transaction
from django.db.models import Sum
from django.views import View
from .models import Customer, SalesInvoice, SalesInvoiceLine, CustomerReceipt, SalesRepresentative, SalesReturn, Quotation, QuotationLine
from .forms import (
    CustomerForm, SalesInvoiceForm, SalesInvoiceLineFormSet, 
    CustomerReceiptForm, SalesRepresentativeForm, SalesReturnLineFormSet,
    QuotationForm, QuotationLineFormSet
)
from .services import CustomerService, SalesRepresentativeService, SalesService, RepSettlementService

class QuotationListView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    model = Quotation
    template_name = 'sales/quotations/list.html'
    context_object_name = 'quotations'
    permission_required = 'sales.view_quotation'
    ordering = ['-date', '-id']

class QuotationCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    model = Quotation
    form_class = QuotationForm
    template_name = 'sales/quotations/form.html'
    permission_required = 'sales.add_quotation'
    success_url = reverse_lazy('sales:quotation-list')

    def get_context_data(self, **kwargs):
        data = super().get_context_data(**kwargs)
        if self.request.POST:
            data['lines'] = QuotationLineFormSet(self.request.POST)
        else:
            data['lines'] = QuotationLineFormSet()
        return data

    def form_valid(self, form):
        context = self.get_context_data()
        lines = context['lines']
        with transaction.atomic():
            form.instance.created_by = self.request.user
            from apps.core.services import DocumentService
            form.instance.number = DocumentService.generate_number(Quotation, 'QUO')
            
            form.instance.subtotal = 0
            form.instance.total = 0
            self.object = form.save()
            
            if lines.is_valid():
                lines.instance = self.object
                lines.save()
                self.object.subtotal = sum(line.total for line in self.object.lines.all())
                # Simplified total calculation
                self.object.total = self.object.subtotal + self.object.tax_amount - self.object.discount_amount
                self.object.save()
            else:
                return self.form_invalid(form)
        return redirect(self.success_url)

class QuotationDetailView(LoginRequiredMixin, PermissionRequiredMixin, DetailView):
    model = Quotation
    template_name = 'sales/quotations/detail.html'
    context_object_name = 'quotation'
    permission_required = 'sales.view_quotation'

class QuotationConvertToInvoiceView(LoginRequiredMixin, PermissionRequiredMixin, View):
    permission_required = 'sales.add_salesinvoice'

    def post(self, request, pk):
        quotation = get_object_or_404(Quotation, pk=pk)
        if quotation.status == Quotation.Status.INVOICED:
            messages.warning(request, "هذا العرض تم تحويله بالفعل لفاتورة")
            return redirect('sales:quotation-detail', pk=pk)
        
        try:
            with transaction.atomic():
                # Create Invoice
                from apps.core.services import DocumentService
                invoice = SalesInvoice.objects.create(
                    number=DocumentService.generate_number(SalesInvoice, 'SINV'),
                    date=date.today(),
                    customer=quotation.customer,
                    sales_rep=quotation.sales_rep,
                    due_date=date.today(),
                    subtotal=quotation.subtotal,
                    discount_amount=quotation.discount_amount,
                    tax_amount=quotation.tax_amount,
                    total=quotation.total,
                    created_by=request.user,
                    notes=f"محول من عرض سعر رقم {quotation.number}"
                )
                
                # Create Lines
                from apps.core.models import Account
                from django.conf import settings
                default_sales_acc = Account.objects.get(code=getattr(settings, 'DEFAULT_SALES_ACCOUNT', '411'))

                for q_line in quotation.lines.all():
                    SalesInvoiceLine.objects.create(
                        invoice=invoice,
                        item=q_line.item,
                        warehouse=quotation.sales_rep.warehouse if quotation.sales_rep else None,
                        quantity=q_line.quantity,
                        unit_price=q_line.unit_price,
                        discount_percent=q_line.discount_percent,
                        tax_type=q_line.tax_type,
                        tax_percent=q_line.tax_percent,
                        total=q_line.total,
                        revenue_account=q_line.item.sales_account or default_sales_acc,
                        cost_of_goods_account=q_line.item.cogs_account
                    )
                
                quotation.status = Quotation.Status.INVOICED
                quotation.save()
                
                messages.success(request, f"تم تحويل عرض السعر لفاتورة بنجاح: {invoice.number}")
                return redirect('sales:invoice-detail', pk=invoice.pk)
        except Exception as e:
            messages.error(request, f"خطأ أثناء التحويل: {e}")
            return redirect('sales:quotation-detail', pk=pk)

from apps.core.models import JournalLine
from datetime import datetime, date

class CustomerListView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    model = Customer
    template_name = 'sales/customers/list.html'
    context_object_name = 'customers'
    permission_required = 'sales.view_customer'
    paginate_by = 25

    def get_queryset(self):
        qs = Customer.objects.select_related('account').order_by('code')
        q = self.request.GET.get('q')
        if q:
            qs = qs.filter(name__icontains=q) | qs.filter(code__icontains=q)
        return qs

class CustomerCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    model = Customer
    form_class = CustomerForm
    template_name = 'sales/customers/form.html'
    permission_required = 'sales.add_customer'
    success_url = reverse_lazy('sales:customer-list')

    def form_valid(self, form):
        try:
            customer = CustomerService.create_customer(form.cleaned_data)
            messages.success(
                self.request,
                f'تم إنشاء العميل "{customer.name}" بنجاح — كود الحساب: {customer.account.code}'
            )
            from django.shortcuts import redirect
            return redirect(self.success_url)
        except Exception as e:
            messages.error(self.request, f'خطأ: {e}')
            return self.form_invalid(form)

class CustomerUpdateView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    model = Customer
    form_class = CustomerForm
    template_name = 'sales/customers/form.html'
    permission_required = 'sales.change_customer'
    success_url = reverse_lazy('sales:customer-list')

    def form_valid(self, form):
        CustomerService.update_customer(self.object, form.cleaned_data)
        messages.success(self.request, 'تم تحديث بيانات العميل بنجاح')
        from django.shortcuts import redirect
        return redirect(self.success_url)

class CustomerDetailView(LoginRequiredMixin, PermissionRequiredMixin, DetailView):
    model = Customer
    template_name = 'sales/customers/detail.html'
    permission_required = 'sales.view_customer'

    def get_context_data(self, **kwargs):
        from apps.core.utils import get_account_balance
        from datetime import date
        ctx = super().get_context_data(**kwargs)
        ctx['invoices'] = self.object.salesinvoice_set.order_by('-date')[:10]
        ctx['balance'] = get_account_balance(self.object.account) if self.object.account else 0
        return ctx

# --- Sales Representative Views ---

class SalesRepresentativeListView(LoginRequiredMixin, ListView):
    model = SalesRepresentative
    template_name = 'sales/reps/list.html'
    context_object_name = 'reps'

class SalesRepresentativeDetailView(LoginRequiredMixin, DetailView):
    model = SalesRepresentative
    template_name = 'sales/reps/detail.html'
    context_object_name = 'rep'

class SalesRepresentativeCreateView(LoginRequiredMixin, CreateView):
    model = SalesRepresentative
    form_class = SalesRepresentativeForm
    template_name = 'sales/reps/form.html'
    success_url = reverse_lazy('sales:rep-list')

    def form_valid(self, form):
        self.object = SalesRepresentativeService.create_rep(form.cleaned_data)
        return redirect(self.success_url)

class SalesRepresentativeUpdateView(LoginRequiredMixin, UpdateView):
    model = SalesRepresentative
    form_class = SalesRepresentativeForm
    template_name = 'sales/reps/form.html'
    success_url = reverse_lazy('sales:rep-list')

class SalesInvoiceListView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    model = SalesInvoice
    template_name = 'sales/invoices/list.html'
    context_object_name = 'invoices'

    ordering = ['-date', '-id']
    permission_required = 'sales.view_salesinvoice'

    def get_queryset(self):
        qs = super().get_queryset().select_related('customer')
        q = self.request.GET.get('q')
        if q:
            qs = qs.filter(number__icontains=q) | qs.filter(customer__name__icontains=q)
        return qs

class SalesInvoiceCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    model = SalesInvoice
    form_class = SalesInvoiceForm
    template_name = 'sales/invoices/form.html'
    permission_required = 'sales.add_salesinvoice'
    success_url = reverse_lazy('sales:invoice-list')

    def get_context_data(self, **kwargs):
        data = super().get_context_data(**kwargs)
        if self.request.POST:
            data['lines'] = SalesInvoiceLineFormSet(self.request.POST)
        else:
            data['lines'] = SalesInvoiceLineFormSet()
        return data

    def form_valid(self, form):
        context = self.get_context_data()
        lines = context['lines']
        with transaction.atomic():
            form.instance.created_by = self.request.user
            from apps.core.services import DocumentService
            form.instance.number = DocumentService.generate_number(SalesInvoice, 'SINV')
            
            form.instance.subtotal = 0
            form.instance.total = 0
            self.object = form.save()
            
            if lines.is_valid():
                from apps.core.models import Account
                from django.conf import settings
                default_sales_acc = Account.objects.get(code=getattr(settings, 'DEFAULT_SALES_ACCOUNT', '411'))

                lines.instance = self.object
                instances = lines.save(commit=False)
                from apps.inventory.services import InventoryService
                for instance in instances:
                    instance.revenue_account = instance.item.sales_account or default_sales_acc
                    instance.cost_of_goods_account = instance.item.cogs_account
                    # Store current cost for accurate COGS tracking
                    instance.cost = InventoryService.get_item_cost(instance.item, instance.warehouse)
                    instance.save()
                
                # Also handle deleted lines if any
                for obj in lines.deleted_objects:
                    obj.delete()

                self.object.subtotal = sum(line.total for line in self.object.lines.all())
                self.object.total = self.object.subtotal + self.object.tax_amount - self.object.discount_amount
                self.object.save()
            else:
                return self.form_invalid(form)
        return redirect(self.success_url)

class SalesInvoicePostView(LoginRequiredMixin, PermissionRequiredMixin, View):
    permission_required = 'sales.change_salesinvoice'
    
    def post(self, request, pk):
        invoice = get_object_or_404(SalesInvoice, pk=pk)
        try:
            SalesService.post_invoice(invoice, request.user)
            messages.success(request, f'تم ترحيل الفاتورة {invoice.number} بنجاح')
        except Exception as e:
            messages.error(request, f'خطأ أثناء الترحيل: {e}')
        return redirect('sales:invoice-list')

class CustomerReceiptListView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    model = CustomerReceipt
    template_name = 'sales/receipts/list.html'
    context_object_name = 'receipts'
    permission_required = 'sales.view_customerreceipt'

class CustomerReceiptCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    model = CustomerReceipt
    form_class = CustomerReceiptForm
    template_name = 'sales/receipts/form.html'
    success_url = reverse_lazy('sales:receipt-list')
    permission_required = 'sales.add_customerreceipt'

    def form_valid(self, form):
        with transaction.atomic():
            from apps.core.services import DocumentService
            form.instance.number = DocumentService.generate_number(CustomerReceipt, 'RCPT')
            self.object = form.save()
            
            SalesService.record_receipt(self.object, self.request.user)
            messages.success(self.request, f'تم تسجيل السند {self.object.number} وترحيله بنجاح')
        return redirect('sales:receipt-detail', pk=self.object.pk)

class CustomerReceiptDetailView(LoginRequiredMixin, PermissionRequiredMixin, DetailView):
    model = CustomerReceipt
    template_name = 'sales/receipts/detail.html'
    context_object_name = 'receipt'
    permission_required = 'sales.view_customerreceipt'

class ChequeCollectionView(LoginRequiredMixin, PermissionRequiredMixin, View):
    permission_required = 'sales.change_customerreceipt'

    def post(self, request, pk):
        from .services import SalesService
        from apps.treasury.models import BankAccount
        from datetime import date as date_type
        
        receipt = get_object_or_404(CustomerReceipt, pk=pk)
        bank_id = request.POST.get('bank')
        collection_date_str = request.POST.get('date')
        
        if not bank_id or not collection_date_str:
            messages.error(request, "يجب تحديد البنك وتاريخ التحصيل")
            return redirect('sales:receipt-detail', pk=pk)
            
        try:
            bank = BankAccount.objects.get(pk=bank_id)
            collection_date = date_type.fromisoformat(collection_date_str)
            SalesService.collect_cheque(receipt, bank, collection_date, request.user)
            messages.success(request, f'تم تحصيل الشيك {receipt.cheque_number} بنجاح')
        except Exception as e:
            messages.error(request, f'خطأ أثناء التحصيل: {e}')
            
        return redirect('sales:receipt-detail', pk=pk)

class CustomerStatementView(LoginRequiredMixin, PermissionRequiredMixin, DetailView):
    model = Customer
    template_name = 'sales/customers/statement.html'
    context_object_name = 'customer'
    permission_required = 'sales.view_customer'

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        customer = self.get_object()
        
        start_date = self.request.GET.get('start_date')
        end_date = self.request.GET.get('end_date')
        
        if not start_date:
            start_date = date(date.today().year, date.today().month, 1).strftime('%Y-%m-%d')
        if not end_date:
            end_date = date.today().strftime('%Y-%m-%d')
            
        ctx['start_date'] = start_date
        ctx['end_date'] = end_date
        
        # Get all journal lines for this customer account
        lines = JournalLine.objects.filter(
            account=customer.account,
            entry__is_posted=True,
            entry__date__range=[start_date, end_date]
        ).select_related('entry').order_by('entry__date', 'entry__id')
        
        # Calculate opening balance
        opening_balance = JournalLine.objects.filter(
            account=customer.account,
            entry__is_posted=True,
            entry__date__lt=start_date
        ).aggregate(
            bal=Sum('debit') - Sum('credit')
        )['bal'] or 0
        
        ctx['opening_balance'] = opening_balance
        
        # Calculate running balance
        running_bal = opening_balance
        statement_lines = []
        for l in lines:
            running_bal += (l.debit - l.credit)
            statement_lines.append({
                'date': l.entry.date,
                'number': l.entry.number,
                'description': l.entry.description,
                'debit': l.debit,
                'credit': l.credit,
                'balance': running_bal
            })
            
        ctx['statement_lines'] = statement_lines
        ctx['closing_balance'] = running_bal
        return ctx

class SalesInvoiceDetailView(LoginRequiredMixin, PermissionRequiredMixin, DetailView):
    model = SalesInvoice
    template_name = 'sales/invoices/detail.html'
    context_object_name = 'invoice'
    permission_required = 'sales.view_salesinvoice'

from decimal import Decimal
from django.shortcuts import render
from apps.treasury.models import CashBox

class RepDailySettlementListView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    from .models import RepDailySettlement
    model = RepDailySettlement
    template_name = 'sales/settlements/list.html'
    permission_required = 'sales.view_repdailysettlement'
    paginate_by = 25

    def get_queryset(self):
        from .models import RepDailySettlement
        qs = RepDailySettlement.objects.select_related(
            'sales_rep', 'to_cash_box', 'to_bank'
        ).order_by('-date', '-created_at')
        rep_id = self.request.GET.get('rep')
        if rep_id:
            qs = qs.filter(sales_rep_id=rep_id)
        date = self.request.GET.get('date')
        if date:
            qs = qs.filter(date=date)
        return qs

class RepDailySettlementCreateView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    صفحة إنشاء تسوية المندوب.
    تعرض: المندوب + التاريخ + الفواتير النقدية تلقائياً + حقل النقدية المستلمة.
    """
    template_name = 'sales/settlements/form.html'
    permission_required = 'sales.add_repdailysettlement'

    def get(self, request):
        from datetime import date as today_date
        reps = SalesRepresentative.objects.filter(is_active=True)
        cash_boxes = CashBox.objects.filter(is_active=True)
        return render(request, self.template_name, {
            'reps': reps,
            'cash_boxes': cash_boxes,
            'today': today_date.today().isoformat(),
        })

    def post(self, request):
        rep_id       = request.POST.get('rep')
        date_val     = request.POST.get('date')
        cash_delivered = Decimal(request.POST.get('cash_delivered', '0'))
        to_cash_box_id = request.POST.get('to_cash_box')
        to_bank_id     = request.POST.get('to_bank')
        invoice_ids    = request.POST.getlist('invoice_ids')  # checkboxes

        from django.db import transaction
        try:
            with transaction.atomic():
                from datetime import date as date_type
                from decimal import Decimal
                from .models import RepDailySettlement, RepSettlementInvoice
                from .services import RepSettlementService
                from apps.core.services import DocumentService
                
                rep  = SalesRepresentative.objects.get(pk=rep_id)
                date = date_type.fromisoformat(date_val)

                settlement = RepDailySettlement.objects.create(
                    number=DocumentService.generate_number(RepDailySettlement, 'RS'),
                    date=date,
                    sales_rep=rep,
                    cash_delivered=cash_delivered,
                    to_cash_box_id=to_cash_box_id or None,
                    to_bank_id=to_bank_id or None,
                    created_by=request.user,
                )

                # ربط الفواتير المختارة
                invoices = SalesInvoice.objects.filter(pk__in=invoice_ids)
                for inv in invoices:
                    RepSettlementInvoice.objects.create(
                        settlement=settlement, invoice=inv
                    )

                # ترحيل مباشر
                RepSettlementService.post_settlement(settlement, request.user)

                messages.success(
                    request,
                    f'تم ترحيل تسوية المندوب {rep.name} بنجاح — '
                    f'الفرق: {settlement.difference}'
                )
            return redirect('sales:settlement-list')

        except Exception as e:
            messages.error(request, f'خطأ: {e}')
            return redirect('sales:settlement-create')

class RepDailySettlementDetailView(LoginRequiredMixin, PermissionRequiredMixin, DetailView):
    from .models import RepDailySettlement
    model = RepDailySettlement
    template_name = 'sales/settlements/detail.html'
    context_object_name = 'settlement'
    permission_required = 'sales.view_repdailysettlement'

class RepUnsettledInvoicesView(LoginRequiredMixin, View):
    """
    HTMX endpoint — يجيب الفواتير غير المسواة للمندوب في يوم معين
    يُستدعى عند تغيير المندوب أو التاريخ في الـ form
    """
    def get(self, request):
        from .services import RepSettlementService
        rep_id   = request.GET.get('rep')
        date_val = request.GET.get('date')
        if not rep_id or not date_val:
            from django.http import HttpResponse
            return HttpResponse('')
        from datetime import date as date_type
        rep  = get_object_or_404(SalesRepresentative, pk=rep_id)
        date = date_type.fromisoformat(date_val)
        invoices = RepSettlementService.get_unsettled_invoices(rep, date)
        total    = sum(inv.total for inv in invoices)
        return render(request, 'sales/settlements/_invoice_table.html', {
            'invoices': invoices,
            'total': total,
            'rep': rep,
        })

class RepReceivableCollectView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """تحصيل ذمة متراكمة على مندوب"""
    permission_required = 'sales.change_repdailysettlement'
    template_name = 'sales/reps/collect_form.html'

    def get(self, request, rep_pk):
        from apps.treasury.models import CashBox, BankAccount
        from datetime import date as today_date
        rep = get_object_or_404(SalesRepresentative, pk=rep_pk)
        cash_boxes = CashBox.objects.filter(is_active=True)
        banks = BankAccount.objects.filter(is_active=True)
        return render(request, self.template_name, {
            'rep': rep,
            'cash_boxes': cash_boxes,
            'banks': banks,
            'today': today_date.today().isoformat(),
        })

    def post(self, request, rep_pk):
        from decimal import Decimal
        from datetime import date as date_type
        from .services import RepSettlementService
        rep      = get_object_or_404(SalesRepresentative, pk=rep_pk)
        amount   = Decimal(request.POST.get('amount', '0'))
        date     = date_type.fromisoformat(request.POST.get('date'))
        cash_box_id = request.POST.get('cash_box')
        bank_id     = request.POST.get('bank')

        if cash_box_id:
            dest = CashBox.objects.get(pk=cash_box_id).account
        else:
            from apps.treasury.models import BankAccount
            dest = BankAccount.objects.get(pk=bank_id).account

        try:
            RepSettlementService.collect_rep_receivable(
                rep, amount, dest, date, request.user
            )
            messages.success(request, f'تم تحصيل {amount} من ذمة المندوب {rep.name}')
        except Exception as e:
            messages.error(request, f'خطأ: {e}')

        return redirect('sales:rep-detail', pk=rep_pk)

class SalesReturnListView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    model = SalesReturn
    template_name = 'sales/returns/list.html'
    context_object_name = 'returns'
    permission_required = 'sales.view_salesreturn'
    ordering = ['-date', '-id']

class SalesReturnCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    model = SalesReturn
    fields = ['date', 'invoice', 'customer', 'sales_rep', 'notes']
    template_name = 'sales/returns/form.html'
    permission_required = 'sales.add_salesreturn'
    success_url = reverse_lazy('sales:return-list')

    def get_context_data(self, **kwargs):
        from .forms import SalesReturnLineFormSet
        data = super().get_context_data(**kwargs)
        if self.request.POST:
            data['lines'] = SalesReturnLineFormSet(self.request.POST)
        else:
            data['lines'] = SalesReturnLineFormSet()
        return data

    def form_valid(self, form):
        context = self.get_context_data()
        lines = context['lines']
        with transaction.atomic():
            form.instance.created_by = self.request.user
            from apps.core.services import DocumentService
            form.instance.number = DocumentService.generate_number(SalesReturn, 'SRET')
            
            form.instance.subtotal = 0
            form.instance.total = 0
            self.object = form.save()
            
            if lines.is_valid():
                from apps.core.models import Account
                from django.conf import settings
                default_ret_acc = Account.objects.get(code=getattr(settings, 'DEFAULT_SALES_RETURN_ACCOUNT', '413'))
                default_cogs_acc = Account.objects.get(code=getattr(settings, 'DEFAULT_COGS_ACCOUNT', '51'))

                lines.instance = self.object
                instances = lines.save(commit=False)
                for instance in instances:
                    if not instance.return_account_id:
                        instance.return_account = default_ret_acc
                    if not instance.cogs_account_id:
                        instance.cogs_account = instance.item.cogs_account or default_cogs_acc
                    instance.save()
                
                for obj in lines.deleted_objects:
                    obj.delete()

                self.object.subtotal = sum(line.total for line in self.object.lines.all())
                self.object.total = self.object.subtotal + self.object.tax_amount - self.object.discount_amount
                self.object.save()
            else:
                return self.form_invalid(form)
        return redirect(self.success_url)

class SalesReturnDetailView(LoginRequiredMixin, PermissionRequiredMixin, DetailView):
    model = SalesReturn
    template_name = 'sales/returns/detail.html'
    context_object_name = 'sales_return'
    permission_required = 'sales.view_salesreturn'

class SalesReturnPostView(LoginRequiredMixin, PermissionRequiredMixin, View):
    permission_required = 'sales.change_salesreturn'
    
    def post(self, request, pk):
        sales_return = get_object_or_404(SalesReturn, pk=pk)
        try:
            SalesService.post_return(sales_return, request.user)
            messages.success(request, f'تم ترحيل المرتجع {sales_return.number} بنجاح')
        except Exception as e:
            messages.error(request, f'خطأ أثناء الترحيل: {e}')
        return redirect('sales:return-detail', pk=pk)

from django.http import JsonResponse

class RepDetailsAPIView(LoginRequiredMixin, View):
    def get(self, request, pk):
        rep = get_object_or_404(SalesRepresentative, pk=pk)
        return JsonResponse({
            'warehouse_id': rep.warehouse_id,
            'cash_box_id': rep.cash_box_id
        })
